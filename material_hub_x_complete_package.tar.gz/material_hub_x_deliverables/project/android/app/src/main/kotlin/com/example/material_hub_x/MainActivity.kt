package com.example.material_hub_x

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
