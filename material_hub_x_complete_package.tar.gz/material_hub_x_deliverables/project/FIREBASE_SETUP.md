# Firebase Setup Guide for Material Hub X

This guide provides detailed instructions for setting up Firebase for the Material Hub X application, including all necessary configurations for Authentication, Firestore, and Storage.

## 🔥 Firebase Project Creation

### Step 1: Create Firebase Project

1. **Go to Firebase Console**
   - Visit [https://console.firebase.google.com/](https://console.firebase.google.com/)
   - Sign in with your Google account

2. **Create New Project**
   - Click "Create a project"
   - Enter project name: `material-hub-x` (or your preferred name)
   - Choose whether to enable Google Analytics
   - Select Analytics account if enabled
   - Click "Create project"

3. **Wait for Setup**
   - Firebase will set up your project
   - Click "Continue" when ready

## 🔐 Authentication Setup

### Step 1: Enable Authentication

1. **Navigate to Authentication**
   - In Firebase Console, click "Authentication" in the left sidebar
   - Click "Get started"

2. **Configure Sign-in Methods**
   - Go to "Sign-in method" tab
   - Click on "Email/Password"
   - Enable "Email/Password"
   - Optionally enable "Email link (passwordless sign-in)"
   - Click "Save"

### Step 2: Configure Settings

1. **User Actions**
   - Go to "Settings" tab in Authentication
   - Configure "Authorized domains" if needed
   - Add your domain for web deployment

2. **Templates (Optional)**
   - Customize email templates for:
     - Email verification
     - Password reset
     - Email address change

## 🗄️ Firestore Database Setup

### Step 1: Create Firestore Database

1. **Navigate to Firestore**
   - Click "Firestore Database" in the left sidebar
   - Click "Create database"

2. **Choose Security Rules**
   - Select "Start in test mode" (we'll update rules later)
   - Click "Next"

3. **Select Location**
   - Choose a location close to your users
   - **Important**: This cannot be changed later
   - Click "Done"

### Step 2: Create Collections

Create the following collections with sample documents:

#### Users Collection
```javascript
// Collection: users
// Document ID: [auto-generated or user UID]
{
  "uid": "user123",
  "email": "student@example.com",
  "name": "John Doe",
  "selectedInstitute": "ARJUNA JEE 2026",
  "selectedClass": "12th - IIT JEE",
  "xp": 150,
  "rank": 25,
  "createdAt": "2024-01-15T10:30:00Z",
  "lastActiveAt": "2024-01-20T14:45:00Z",
  "preferences": {
    "theme": "light",
    "notifications": true
  }
}
```

#### Tests Collection
```javascript
// Collection: tests
// Document ID: test_1
{
  "id": "test_1",
  "title": "Physics - Mechanics Mock Test",
  "description": "Comprehensive test covering Newton's laws and motion",
  "institute": "ARJUNA JEE 2026",
  "subject": "Physics",
  "difficulty": "Medium",
  "duration": 60,
  "totalQuestions": 30,
  "questions": [
    {
      "id": "q1",
      "question": "What is the acceleration due to gravity on Earth?",
      "options": ["9.8 m/s²", "10 m/s²", "8.9 m/s²", "11 m/s²"],
      "correctAnswer": 0,
      "explanation": "The standard acceleration due to gravity on Earth is approximately 9.8 m/s².",
      "marks": 1
    }
  ],
  "createdAt": "2024-01-15T10:00:00Z",
  "isActive": true
}
```

#### Materials Collection
```javascript
// Collection: materials
// Document ID: material_1
{
  "id": "material_1",
  "title": "Physics Formula Sheet",
  "description": "Complete formula sheet for JEE Physics",
  "institute": "ARJUNA JEE 2026",
  "subject": "Physics",
  "type": "pdf",
  "downloadUrl": "https://firebasestorage.googleapis.com/...",
  "thumbnailUrl": "https://firebasestorage.googleapis.com/...",
  "fileSize": 2048000,
  "uploadedAt": "2024-01-15T09:00:00Z",
  "isPremium": false,
  "tags": ["formulas", "reference", "jee"]
}
```

#### Test Results Collection
```javascript
// Collection: test_results
// Document ID: [auto-generated]
{
  "id": "result_1",
  "userId": "user123",
  "testId": "test_1",
  "score": 25,
  "totalQuestions": 30,
  "timeTaken": 3600,
  "answers": {
    "q1": 0,
    "q2": 2
  },
  "completedAt": "2024-01-20T15:30:00Z",
  "xpEarned": 40
}
```

#### Downloads Collection
```javascript
// Collection: downloads
// Document ID: [auto-generated]
{
  "id": "download_1",
  "userId": "user123",
  "materialId": "material_1",
  "downloadedAt": "2024-01-20T12:00:00Z",
  "localPath": "/data/user/0/com.example.material_hub_x/files/downloads/material_1_physics_formulas.pdf"
}
```

#### Doubts Collection
```javascript
// Collection: doubts
// Document ID: [auto-generated]
{
  "id": "doubt_1",
  "userId": "user123",
  "title": "Confusion about Newton's Third Law",
  "description": "I don't understand how action and reaction forces work in different scenarios...",
  "subject": "Physics",
  "imageUrl": null,
  "createdAt": "2024-01-20T11:00:00Z",
  "isResolved": false,
  "replies": [
    {
      "id": "reply_1",
      "doubtId": "doubt_1",
      "userId": "teacher123",
      "userName": "Prof. Smith",
      "reply": "Newton's third law states that for every action, there is an equal and opposite reaction...",
      "createdAt": "2024-01-20T13:00:00Z",
      "isTeacher": true
    }
  ]
}
```

### Step 3: Configure Security Rules

1. **Go to Rules Tab**
   - In Firestore Database, click "Rules" tab

2. **Update Rules**
   - Replace the default rules with:

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // Users can read and write their own user document
    match /users/{userId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
      // Allow reading other users' public data for leaderboard
      allow read: if request.auth != null && 
        resource.data.keys().hasAny(['uid', 'name', 'xp', 'rank']);
    }
    
    // Tests are read-only for authenticated users
    match /tests/{testId} {
      allow read: if request.auth != null;
      allow write: if request.auth != null && 
        request.auth.token.admin == true; // Only admins can create/update tests
    }
    
    // Test results can be created by the user who took the test
    match /test_results/{resultId} {
      allow read, write: if request.auth != null && 
        request.auth.uid == resource.data.userId;
      allow create: if request.auth != null && 
        request.auth.uid == request.resource.data.userId;
    }
    
    // Materials are read-only for authenticated users
    match /materials/{materialId} {
      allow read: if request.auth != null;
      allow write: if request.auth != null && 
        request.auth.token.admin == true; // Only admins can upload materials
    }
    
    // Downloads can be created and read by the user
    match /downloads/{downloadId} {
      allow read, write: if request.auth != null && 
        request.auth.uid == resource.data.userId;
      allow create: if request.auth != null && 
        request.auth.uid == request.resource.data.userId;
    }
    
    // Doubts can be created and read by authenticated users
    match /doubts/{doubtId} {
      allow read: if request.auth != null;
      allow create: if request.auth != null && 
        request.auth.uid == request.resource.data.userId;
      allow update: if request.auth != null && (
        request.auth.uid == resource.data.userId || // User can update their own doubt
        request.auth.token.admin == true || // Admins can update any doubt
        // Allow adding replies
        request.resource.data.diff(resource.data).affectedKeys().hasOnly(['replies'])
      );
    }
    
    // Default deny rule
    match /{document=**} {
      allow read, write: if false;
    }
  }
}
```

3. **Publish Rules**
   - Click "Publish"

## 📁 Firebase Storage Setup

### Step 1: Enable Storage

1. **Navigate to Storage**
   - Click "Storage" in the left sidebar
   - Click "Get started"

2. **Configure Security Rules**
   - Choose "Start in test mode"
   - Click "Next"

3. **Select Location**
   - Choose the same location as Firestore
   - Click "Done"

### Step 2: Create Folder Structure

Create the following folder structure:

```
/materials/
  /pdfs/
  /videos/
  /images/
/profile_pictures/
/doubt_images/
/test_images/
```

### Step 3: Configure Storage Rules

1. **Go to Rules Tab**
   - In Storage, click "Rules" tab

2. **Update Rules**
   - Replace with:

```javascript
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    // Users can upload profile pictures
    match /profile_pictures/{userId}/{allPaths=**} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
    
    // Users can upload doubt images
    match /doubt_images/{userId}/{allPaths=**} {
      allow read: if request.auth != null;
      allow write: if request.auth != null && request.auth.uid == userId;
    }
    
    // Materials can only be uploaded by admins
    match /materials/{allPaths=**} {
      allow read: if request.auth != null;
      allow write: if request.auth != null && request.auth.token.admin == true;
    }
    
    // Test images can only be uploaded by admins
    match /test_images/{allPaths=**} {
      allow read: if request.auth != null;
      allow write: if request.auth != null && request.auth.token.admin == true;
    }
    
    // Default deny rule
    match /{allPaths=**} {
      allow read, write: if false;
    }
  }
}
```

3. **Publish Rules**
   - Click "Publish"

## 📱 Android App Configuration

### Step 1: Add Android App

1. **Add App to Project**
   - In Firebase Console, click the Android icon
   - Enter package name: `com.example.material_hub_x`
   - Enter app nickname: `Material Hub X`
   - Enter SHA-1 certificate (optional for now)
   - Click "Register app"

2. **Download Configuration File**
   - Download `google-services.json`
   - Place it in `android/app/` directory of your Flutter project

### Step 2: Configure Flutter App

1. **Update Firebase Options**
   - Edit `lib/firebase_options.dart`
   - Replace with your project's configuration:

```dart
import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, kIsWeb, TargetPlatform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      return web;
    }
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
        return ios;
      default:
        throw UnsupportedError(
          'DefaultFirebaseOptions are not supported for this platform.',
        );
    }
  }

  static const FirebaseOptions web = FirebaseOptions(
    apiKey: 'your-web-api-key',
    appId: 'your-web-app-id',
    messagingSenderId: 'your-sender-id',
    projectId: 'your-project-id',
    authDomain: 'your-project-id.firebaseapp.com',
    storageBucket: 'your-project-id.appspot.com',
  );

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'your-android-api-key',
    appId: 'your-android-app-id',
    messagingSenderId: 'your-sender-id',
    projectId: 'your-project-id',
    storageBucket: 'your-project-id.appspot.com',
  );

  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: 'your-ios-api-key',
    appId: 'your-ios-app-id',
    messagingSenderId: 'your-sender-id',
    projectId: 'your-project-id',
    storageBucket: 'your-project-id.appspot.com',
    iosBundleId: 'com.example.materialHubX',
  );
}
```

## 🔧 Advanced Configuration

### Admin Users Setup

To create admin users who can upload materials and tests:

1. **Create Custom Claims**
   - Use Firebase Admin SDK or Firebase CLI
   - Set custom claims for admin users:

```javascript
// Using Firebase Admin SDK
admin.auth().setCustomUserClaims(uid, { admin: true });
```

2. **Verify Admin Access**
   - Admin users can now upload materials and create tests
   - Regular users have read-only access

### Indexes Configuration

For better query performance, create these indexes:

1. **Go to Firestore Indexes**
   - In Firestore, click "Indexes" tab

2. **Create Composite Indexes**
   - Collection: `materials`
   - Fields: `institute` (Ascending), `subject` (Ascending), `uploadedAt` (Descending)
   
   - Collection: `tests`
   - Fields: `institute` (Ascending), `subject` (Ascending), `isActive` (Ascending)
   
   - Collection: `users`
   - Fields: `xp` (Descending)

### Backup Configuration

1. **Enable Automatic Backups**
   - Go to "Backups" in Firestore
   - Enable automatic daily backups
   - Set retention period (recommended: 30 days)

2. **Export Data**
   - Use Firebase CLI for manual exports:
   ```bash
   firebase firestore:export gs://your-bucket/exports/
   ```

## 🚀 Deployment

### Deploy Security Rules

1. **Install Firebase CLI**
   ```bash
   npm install -g firebase-tools
   firebase login
   ```

2. **Initialize Firebase in Project**
   ```bash
   cd your-flutter-project
   firebase init
   ```

3. **Deploy Rules**
   ```bash
   firebase deploy --only firestore:rules
   firebase deploy --only storage
   ```

### Environment Configuration

For different environments (dev, staging, prod):

1. **Create Multiple Projects**
   - Development: `material-hub-x-dev`
   - Staging: `material-hub-x-staging`
   - Production: `material-hub-x-prod`

2. **Use Firebase CLI Aliases**
   ```bash
   firebase use --add
   firebase use dev
   firebase use prod
   ```

## 📊 Monitoring & Analytics

### Enable Analytics

1. **Google Analytics**
   - Enable in Firebase Console
   - Configure events and conversions
   - Set up custom dimensions

2. **Performance Monitoring**
   - Add Firebase Performance SDK
   - Monitor app startup time
   - Track network requests

3. **Crashlytics**
   - Enable crash reporting
   - Set up custom logs
   - Configure alert notifications

## 🔍 Testing

### Test Configuration

1. **Use Emulator Suite**
   ```bash
   firebase emulators:start
   ```

2. **Test Security Rules**
   ```bash
   firebase emulators:exec --only firestore "npm test"
   ```

3. **Validate Data Structure**
   - Test all CRUD operations
   - Verify security rules work correctly
   - Check performance with sample data

## 🆘 Troubleshooting

### Common Issues

1. **Authentication Errors**
   - Check API keys in `google-services.json`
   - Verify package name matches Firebase configuration
   - Ensure Authentication is enabled

2. **Firestore Permission Denied**
   - Check security rules
   - Verify user authentication
   - Test rules in Firebase Console

3. **Storage Upload Failures**
   - Check storage rules
   - Verify file size limits
   - Ensure proper authentication

### Debug Commands

```bash
# Check Firebase configuration
firebase projects:list

# Test Firestore rules
firebase firestore:rules:test

# View logs
firebase functions:log

# Check quota usage
firebase quota
```

## 📚 Additional Resources

- [Firebase Documentation](https://firebase.google.com/docs)
- [Firestore Security Rules](https://firebase.google.com/docs/firestore/security/get-started)
- [Firebase Storage Rules](https://firebase.google.com/docs/storage/security)
- [Firebase CLI Reference](https://firebase.google.com/docs/cli)

---

**Your Firebase setup is now complete!** 🎉

The Material Hub X app should now be able to authenticate users, store data in Firestore, and handle file uploads to Storage with proper security rules in place.

