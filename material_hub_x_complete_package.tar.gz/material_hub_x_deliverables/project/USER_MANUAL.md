# Material Hub X - User Manual

Welcome to Material Hub X, your comprehensive companion for IIT JEE, NEET, and UPSC preparation! This manual will guide you through all the features and help you make the most of your study experience.

## 🚀 Getting Started

### First Time Setup

1. **Download and Install**
   - Download the Material Hub X APK
   - Enable "Install from unknown sources" if needed
   - Install the app on your Android device

2. **Create Account**
   - Open the app
   - Tap "Sign Up" to create a new account
   - Enter your email and password
   - Verify your email if required

3. **Select Your Institute**
   - Choose your preferred coaching institute
   - This determines which study materials you'll see
   - You can change this later in settings

## 📱 App Navigation

### Home Screen

The home screen is your dashboard with:

- **Top Section**: Class/batch selector and theme toggle
- **Preparation Meter**: Shows your progress compared to toppers
- **Quick Access Grid**: Six main features in a 3x2 grid
- **Explore Section**: Additional features and tools
- **Bottom Navigation**: Main app sections

### Bottom Navigation

- **Study**: Access materials and tests
- **Batches**: View your enrolled batches
- **QUIZ**: Take practice quizzes
- **Store**: Browse premium content

## 🎯 Core Features

### 1. XP System & Progress Tracking

#### How XP Works
- Earn **1 XP every 2 minutes** of app usage
- Get **bonus XP** for completing tests:
  - 90%+ score: 50 XP
  - 80-89%: 40 XP
  - 70-79%: 30 XP
  - 60-69%: 20 XP
  - Below 60%: 10 XP
- **Daily login bonus**: 5 XP

#### Viewing Your Progress
- XP is displayed on the home screen
- Check your rank in the leaderboard
- Track improvement over time

### 2. Material Library

#### Accessing Materials
1. Tap **"Library"** from the explore section
2. Browse available materials by:
   - Subject (Physics, Chemistry, Mathematics, Biology)
   - Type (PDF, Video, Notes, Assignment)
   - Search by title or description

#### Downloading Materials
1. Find the material you want
2. Tap **"Download"** button
3. Wait for download to complete
4. Access downloaded files from "Downloads" section

**Important**: You must be logged in to download materials!

#### Material Types
- **📄 PDF**: Study notes and textbooks
- **🎥 Video**: Recorded lectures and explanations
- **📝 Notes**: Quick reference materials
- **📋 Assignment**: Practice problems and homework

### 3. Test Series

#### Taking a Test
1. Go to **"Test Series"** from explore section
2. Select a test from the available list
3. Read test details (duration, questions, difficulty)
4. Tap **"Start Test"** to begin

#### During the Test
- **Timer**: Shows remaining time at the top
- **Question Navigation**: Use the drawer (☰) to jump between questions
- **Progress Bar**: Shows completion percentage
- **Answer Selection**: Tap options to select answers
- **Navigation**: Use "Previous" and "Next" buttons

#### Test Features
- **Auto-submit**: Test submits automatically when time expires
- **Question Status**: 
  - Green: Answered
  - Purple: Current question
  - Gray: Not answered
- **Security**: Screenshots are blocked during tests

#### After the Test
- View your score and percentage
- See XP earned
- Check time taken
- Review correct answers (if available)

### 4. Doubt Resolution

#### Submitting a Doubt
1. Go to **"My Doubts"** section
2. Tap the **"+"** button
3. Fill in:
   - Subject
   - Doubt title
   - Detailed description
4. Tap **"Submit Doubt"**

#### Managing Your Doubts
- View all your submitted doubts
- Check resolution status
- Read replies from teachers and peers
- Mark doubts as resolved

#### Getting Help
- Teachers and verified users can reply to doubts
- Get notifications for new replies
- Engage in discussions for better understanding

### 5. Leaderboard

#### Viewing Rankings
1. Go to **"Leaderboard"** from explore section
2. See top performers with:
   - Rank position
   - XP points
   - User avatars

#### Your Rank
- Check your current rank
- Compare with other students
- Track improvement over time

#### Podium Display
- Top 3 users get special recognition
- Gold, silver, and bronze styling
- Crown icons for winners

### 6. Institute Selection

#### Changing Your Institute
1. Go to **"Institute Materials"** from explore
2. Select a different institute
3. Confirm your choice
4. Materials will update based on selection

#### Available Institutes
- **ARJUNA JEE 2026**: JEE preparation
- **PHOENIX NEET 2026**: NEET preparation  
- **EAGLE UPSC Foundation**: Civil services
- **TITAN JEE Advanced**: Advanced JEE
- **APEX NEET Plus**: NEET with additional exams

## ⚙️ Settings & Customization

### Theme Settings
- Toggle between light and dark mode
- Use the theme button in the top-right corner
- Settings are saved automatically

### Account Management
- View your profile information
- Update email and password
- Check XP and rank statistics

### Notifications
- Enable/disable push notifications
- Set study reminders
- Get updates on new materials

## 🔒 Security Features

### Download Protection
- Materials are only accessible within the app
- Downloaded files are encrypted
- No external access to study materials

### Test Security
- Screenshots are blocked during tests
- Screen recording is prevented
- Security warnings for violations

### Account Security
- Secure Firebase authentication
- Encrypted data transmission
- Regular security updates

## 📊 Study Tips

### Maximizing XP
1. **Stay Active**: Keep the app open while studying
2. **Take Tests Regularly**: Higher scores = more XP
3. **Daily Login**: Don't miss your daily bonus
4. **Complete Challenges**: Participate in special events

### Effective Study Strategy
1. **Download Materials**: Study offline when needed
2. **Take Practice Tests**: Regular assessment is key
3. **Ask Doubts**: Don't hesitate to seek help
4. **Track Progress**: Monitor your improvement
5. **Compete Healthily**: Use leaderboard for motivation

### Test-Taking Tips
1. **Read Instructions**: Understand marking scheme
2. **Time Management**: Don't spend too long on one question
3. **Review Answers**: Use question navigation to check
4. **Stay Calm**: Take breaks if allowed
5. **Learn from Mistakes**: Review incorrect answers

## 🆘 Troubleshooting

### Common Issues

#### Can't Download Materials
- **Check Login**: Ensure you're logged in
- **Internet Connection**: Verify stable internet
- **Storage Space**: Free up device storage
- **Try Again**: Restart the app and retry

#### Test Not Loading
- **Refresh**: Pull down to refresh the test list
- **Update App**: Check for app updates
- **Clear Cache**: Restart the app
- **Contact Support**: Report persistent issues

#### XP Not Updating
- **Sync**: Pull down to refresh on home screen
- **Internet**: Check your connection
- **Time**: XP updates every 2 minutes
- **Restart**: Close and reopen the app

#### Login Problems
- **Password**: Check your password carefully
- **Email**: Verify email address is correct
- **Reset**: Use "Forgot Password" if needed
- **New Account**: Create new account if issues persist

### Getting Help

#### In-App Support
1. Go to settings or help section
2. Submit a support ticket
3. Include details about your issue
4. Wait for response from support team

#### Community Help
- Ask doubts in the doubt section
- Get help from other students
- Participate in study groups
- Share tips and strategies

## 📈 Performance Analytics

### Tracking Your Progress
- **XP Growth**: Monitor daily/weekly XP gains
- **Test Scores**: Track improvement in test performance
- **Subject Wise**: See performance by subject
- **Time Spent**: Understand your study patterns

### Setting Goals
1. **Daily XP Target**: Aim for consistent daily XP
2. **Test Frequency**: Take regular practice tests
3. **Score Improvement**: Set percentage targets
4. **Rank Goals**: Aim for higher leaderboard position

## 🎓 Study Recommendations

### Daily Routine
1. **Morning**: Review downloaded notes
2. **Afternoon**: Take practice tests
3. **Evening**: Submit and resolve doubts
4. **Night**: Review test performance

### Weekly Goals
- Complete 5-7 practice tests
- Download 3-5 new materials
- Resolve all pending doubts
- Improve leaderboard rank

### Monthly Targets
- Achieve 90%+ in practice tests
- Maintain top 10% rank
- Complete all available materials
- Help others with doubts

## 🔄 Updates & New Features

### Staying Updated
- Enable auto-updates in Play Store
- Check app regularly for new features
- Read update notes for improvements
- Provide feedback for better experience

### Upcoming Features
- Live classes integration
- Advanced analytics
- Social study groups
- Offline test mode
- Voice doubt submission

## 📞 Contact & Support

### Getting Help
- **Email**: support@materialhubx.com
- **In-App**: Use the help section
- **FAQ**: Check frequently asked questions
- **Community**: Ask in doubt section

### Feedback
- Rate the app on Play Store
- Submit feature requests
- Report bugs and issues
- Share your success stories

---

**Happy Learning with Material Hub X!** 🎓📚

*Remember: Consistent effort and smart study strategies are the keys to success in competitive exams. Use Material Hub X as your companion in this journey!*

