# Material Hub X - Setup Guide

This guide will walk you through setting up Material Hub X from scratch, including Firebase configuration, development environment setup, and deployment.

## 📋 Prerequisites

Before you begin, ensure you have the following installed:

### Required Software
- **Flutter SDK** (3.24.5 or later)
- **Android Studio** or **VS Code** with Flutter extensions
- **Git** for version control
- **Java JDK** (11 or later)
- **Android SDK** (API level 33 or later)

### Accounts Needed
- **Firebase Account** (Google account)
- **Google Play Console** (for app store deployment)

## 🔧 Development Environment Setup

### 1. Install Flutter

#### Windows
```bash
# Download Flutter SDK from https://flutter.dev/docs/get-started/install/windows
# Extract to C:\flutter
# Add C:\flutter\bin to PATH
```

#### macOS
```bash
# Download Flutter SDK from https://flutter.dev/docs/get-started/install/macos
# Extract to ~/flutter
# Add ~/flutter/bin to PATH
```

#### Linux
```bash
# Download Flutter SDK
wget https://storage.googleapis.com/flutter_infra_release/releases/stable/linux/flutter_linux_3.24.5-stable.tar.xz
tar xf flutter_linux_3.24.5-stable.tar.xz
export PATH="$PATH:`pwd`/flutter/bin"
```

### 2. Verify Flutter Installation
```bash
flutter doctor
```

### 3. Install Android Studio
- Download from https://developer.android.com/studio
- Install Android SDK and build tools
- Set up Android emulator or connect physical device

### 4. Configure IDE
#### VS Code
```bash
# Install Flutter and Dart extensions
code --install-extension Dart-Code.flutter
code --install-extension Dart-Code.dart-code
```

#### Android Studio
- Install Flutter and Dart plugins
- Configure Flutter SDK path

## 🔥 Firebase Setup

### 1. Create Firebase Project

1. Go to [Firebase Console](https://console.firebase.google.com/)
2. Click "Create a project"
3. Enter project name: `material-hub-x`
4. Enable Google Analytics (optional)
5. Click "Create project"

### 2. Configure Authentication

1. In Firebase Console, go to **Authentication**
2. Click **Get started**
3. Go to **Sign-in method** tab
4. Enable **Email/Password** provider
5. Save changes

### 3. Set up Firestore Database

1. Go to **Firestore Database**
2. Click **Create database**
3. Choose **Start in test mode** (we'll add security rules later)
4. Select a location close to your users
5. Click **Done**

### 4. Configure Firebase Storage

1. Go to **Storage**
2. Click **Get started**
3. Choose **Start in test mode**
4. Select same location as Firestore
5. Click **Done**

### 5. Add Android App to Firebase

1. In Firebase Console, click **Add app** → **Android**
2. Enter package name: `com.example.material_hub_x`
3. Enter app nickname: `Material Hub X`
4. Click **Register app**
5. Download `google-services.json`
6. Place file in `android/app/` directory

### 6. Install Firebase CLI

```bash
npm install -g firebase-tools
firebase login
```

## 📱 Project Setup

### 1. Clone Repository
```bash
git clone <repository-url>
cd material_hub_x
```

### 2. Install Dependencies
```bash
flutter pub get
```

### 3. Configure Firebase

#### Update Firebase Options
Edit `lib/firebase_options.dart` with your project details:

```dart
static const FirebaseOptions android = FirebaseOptions(
  apiKey: 'your-api-key',
  appId: 'your-app-id',
  messagingSenderId: 'your-sender-id',
  projectId: 'your-project-id',
  storageBucket: 'your-storage-bucket',
);
```

#### Deploy Security Rules

1. **Firestore Rules**
```bash
firebase deploy --only firestore:rules
```

2. **Storage Rules**
```bash
firebase deploy --only storage
```

### 4. Configure Android

#### Update Package Name (Optional)
If you want to change the package name:

1. Edit `android/app/build.gradle`:
```gradle
android {
    defaultConfig {
        applicationId "com.yourcompany.materialhubx"
        // ...
    }
}
```

2. Update `android/app/src/main/AndroidManifest.xml`
3. Update Firebase configuration

#### Add Permissions
Ensure these permissions are in `android/app/src/main/AndroidManifest.xml`:

```xml
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" />
<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" />
```

## 🗄️ Database Setup

### 1. Create Collections

Run the app once to initialize Firebase, then create these collections in Firestore:

#### Users Collection
- Collection ID: `users`
- Auto-generated documents

#### Tests Collection
- Collection ID: `tests`
- Add sample test documents

#### Materials Collection
- Collection ID: `materials`
- Add sample material documents

#### Test Results Collection
- Collection ID: `test_results`
- Auto-generated documents

#### Downloads Collection
- Collection ID: `downloads`
- Auto-generated documents

#### Doubts Collection
- Collection ID: `doubts`
- Auto-generated documents

### 2. Seed Sample Data

You can use the built-in seeding function:

```dart
// In your app, call this once:
await FirestoreService.seedSampleData();
```

## 🔐 Security Configuration

### 1. Deploy Firestore Rules

Create `firestore.rules` in project root:
```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // Users can read and write their own data
    match /users/{userId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
      allow read: if request.auth != null; // For leaderboard
    }
    
    // Tests are read-only for users
    match /tests/{testId} {
      allow read: if request.auth != null;
    }
    
    // Other rules...
  }
}
```

Deploy:
```bash
firebase deploy --only firestore:rules
```

### 2. Deploy Storage Rules

Create `storage.rules` in project root:
```javascript
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /materials/{allPaths=**} {
      allow read: if request.auth != null;
    }
  }
}
```

Deploy:
```bash
firebase deploy --only storage
```

## 🏃‍♂️ Running the App

### 1. Start Emulator or Connect Device
```bash
# List available devices
flutter devices

# Start Android emulator
flutter emulators --launch <emulator_id>
```

### 2. Run in Debug Mode
```bash
flutter run
```

### 3. Run in Release Mode
```bash
flutter run --release
```

## 📦 Building APK

### 1. Debug APK
```bash
flutter build apk --debug
```
Output: `build/app/outputs/flutter-apk/app-debug.apk`

### 2. Release APK
```bash
flutter build apk --release
```
Output: `build/app/outputs/flutter-apk/app-release.apk`

### 3. App Bundle (for Play Store)
```bash
flutter build appbundle --release
```
Output: `build/app/outputs/bundle/release/app-release.aab`

## 🔑 App Signing (Production)

### 1. Generate Keystore
```bash
keytool -genkey -v -keystore ~/upload-keystore.jks -keyalg RSA -keysize 2048 -validity 10000 -alias upload
```

### 2. Configure Signing

Create `android/key.properties`:
```properties
storePassword=<password>
keyPassword=<password>
keyAlias=upload
storeFile=<path-to-keystore>
```

### 3. Update build.gradle

Edit `android/app/build.gradle`:
```gradle
def keystoreProperties = new Properties()
def keystorePropertiesFile = rootProject.file('key.properties')
if (keystorePropertiesFile.exists()) {
    keystoreProperties.load(new FileInputStream(keystorePropertiesFile))
}

android {
    signingConfigs {
        release {
            keyAlias keystoreProperties['keyAlias']
            keyPassword keystoreProperties['keyPassword']
            storeFile keystoreProperties['storeFile'] ? file(keystoreProperties['storeFile']) : null
            storePassword keystoreProperties['storePassword']
        }
    }
    buildTypes {
        release {
            signingConfig signingConfigs.release
        }
    }
}
```

## 🚀 Deployment

### 1. Google Play Store

1. Create Google Play Console account
2. Create new app
3. Upload signed APK or App Bundle
4. Fill in store listing details
5. Set up content rating
6. Configure pricing and distribution
7. Submit for review

### 2. Firebase App Distribution (Beta Testing)

```bash
# Install Firebase CLI
npm install -g firebase-tools

# Login to Firebase
firebase login

# Upload APK for testing
firebase appdistribution:distribute app-release.apk \
  --app your-app-id \
  --groups "testers"
```

## 🔧 Troubleshooting

### Common Issues

#### 1. Firebase Connection Failed
```bash
# Check google-services.json placement
ls android/app/google-services.json

# Verify Firebase configuration
flutter clean
flutter pub get
```

#### 2. Build Failures
```bash
# Clean build
flutter clean
flutter pub get

# Check Android SDK
flutter doctor

# Update dependencies
flutter pub upgrade
```

#### 3. Permission Denied
```bash
# On Linux/macOS, ensure proper permissions
chmod +x android/gradlew
```

#### 4. Emulator Issues
```bash
# List emulators
flutter emulators

# Create new emulator
flutter emulators --create

# Cold boot emulator
flutter emulators --launch <emulator> --cold-boot
```

### Debug Commands

```bash
# Check Flutter installation
flutter doctor -v

# Analyze code
flutter analyze

# Run tests
flutter test

# Check dependencies
flutter pub deps

# Clean project
flutter clean
```

## 📊 Monitoring & Analytics

### 1. Firebase Analytics
- Automatically tracks user engagement
- Custom events for app-specific metrics
- User demographics and behavior

### 2. Crashlytics
```bash
# Add to pubspec.yaml
firebase_crashlytics: ^3.4.8

# Initialize in main.dart
await Firebase.initializeApp();
FlutterError.onError = FirebaseCrashlytics.instance.recordFlutterFatalError;
```

### 3. Performance Monitoring
```bash
# Add to pubspec.yaml
firebase_performance: ^0.9.3

# Initialize in main.dart
FirebasePerformance.instance;
```

## 🔄 Continuous Integration

### GitHub Actions Example

Create `.github/workflows/flutter.yml`:

```yaml
name: Flutter CI

on:
  push:
    branches: [ main ]
  pull_request:
    branches: [ main ]

jobs:
  build:
    runs-on: ubuntu-latest
    
    steps:
    - uses: actions/checkout@v3
    
    - name: Setup Flutter
      uses: subosito/flutter-action@v2
      with:
        flutter-version: '3.24.5'
    
    - name: Install dependencies
      run: flutter pub get
    
    - name: Analyze code
      run: flutter analyze
    
    - name: Run tests
      run: flutter test
    
    - name: Build APK
      run: flutter build apk --release
```

## 📚 Additional Resources

- [Flutter Documentation](https://flutter.dev/docs)
- [Firebase Documentation](https://firebase.google.com/docs)
- [Material Design Guidelines](https://material.io/design)
- [Android Developer Guide](https://developer.android.com/guide)

## 🆘 Getting Help

If you encounter issues:

1. Check the troubleshooting section above
2. Search existing issues in the repository
3. Create a new issue with detailed information
4. Join the Flutter community for support

---

**Happy Coding!** 🚀

