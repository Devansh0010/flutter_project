import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../screens/leaderboard_screen.dart';
import '../screens/institute_selection_screen.dart';

class ExploreSection extends StatelessWidget {
  const ExploreSection({super.key});

  @override
  Widget build(BuildContext context) {
    final exploreItems = [
      ExploreItem(
        icon: Icons.quiz_outlined,
        title: 'Test Series',
        subtitle: 'Explore available test series here',
        onTap: () {
          Navigator.pushNamed(context, '/quiz');
        },
      ),
      ExploreItem(
        icon: Icons.library_books_outlined,
        title: 'Library',
        subtitle: 'Access all your free study material here',
        onTap: () {
          // TODO: Navigate to library
        },
      ),
      ExploreItem(
        icon: Icons.leaderboard_outlined,
        title: 'Leaderboard',
        subtitle: 'Check your ranking among peers',
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => const LeaderboardScreen(),
            ),
          );
        },
      ),
      ExploreItem(
        icon: Icons.school_outlined,
        title: 'Institute Materials',
        subtitle: 'Select your preferred institute content',
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => const InstituteSelectionScreen(),
            ),
          );
        },
      ),
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Explore Section',
          style: Theme.of(context).textTheme.titleLarge?.copyWith(
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 16),
        ListView.separated(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: exploreItems.length,
          separatorBuilder: (context, index) => const SizedBox(height: 12),
          itemBuilder: (context, index) {
            final item = exploreItems[index];
            return ExploreCard(item: item);
          },
        ),
      ],
    );
  }
}

class ExploreCard extends StatelessWidget {
  final ExploreItem item;

  const ExploreCard({super.key, required this.item});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: InkWell(
        onTap: item.onTap,
        borderRadius: BorderRadius.circular(16),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: AppColors.primaryPurple.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(
                  item.icon,
                  size: 24,
                  color: AppColors.primaryPurple,
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      item.title,
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      item.subtitle,
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: AppColors.mediumGray,
                      ),
                    ),
                  ],
                ),
              ),
              const Icon(
                Icons.arrow_forward_ios,
                size: 16,
                color: AppColors.mediumGray,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class ExploreItem {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  ExploreItem({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });
}

