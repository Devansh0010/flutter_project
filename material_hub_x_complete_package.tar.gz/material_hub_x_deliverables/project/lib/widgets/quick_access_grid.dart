import 'package:flutter/material.dart';
import '../constants/app_colors.dart';

class QuickAccessGrid extends StatelessWidget {
  const QuickAccessGrid({super.key});

  @override
  Widget build(BuildContext context) {
    final quickAccessItems = [
      QuickAccessItem(
        icon: Icons.school_outlined,
        title: 'My Batches',
        onTap: () {
          Navigator.pushNamed(context, '/batches');
        },
      ),
      QuickAccessItem(
        icon: Icons.sports_esports_outlined,
        title: 'Battleground',
        onTap: () {
          // TODO: Navigate to battleground
        },
      ),
      QuickAccessItem(
        icon: Icons.help_outline,
        title: 'My Doubts',
        onTap: () {
          // TODO: Navigate to doubts
        },
      ),
      QuickAccessItem(
        icon: Icons.history,
        title: 'My History',
        onTap: () {
          // TODO: Navigate to history
        },
      ),
      QuickAccessItem(
        icon: Icons.download_outlined,
        title: 'Downloads',
        onTap: () {
          // TODO: Navigate to downloads
        },
      ),
      QuickAccessItem(
        icon: Icons.dashboard_outlined,
        title: 'Dashboard / Bookmarks',
        onTap: () {
          // TODO: Navigate to dashboard
        },
      ),
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Quick Access',
          style: Theme.of(context).textTheme.titleLarge?.copyWith(
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 16),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            crossAxisSpacing: 12,
            mainAxisSpacing: 12,
            childAspectRatio: 1.2,
          ),
          itemCount: quickAccessItems.length,
          itemBuilder: (context, index) {
            final item = quickAccessItems[index];
            return QuickAccessCard(item: item);
          },
        ),
      ],
    );
  }
}

class QuickAccessCard extends StatelessWidget {
  final QuickAccessItem item;

  const QuickAccessCard({super.key, required this.item});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: InkWell(
        onTap: item.onTap,
        borderRadius: BorderRadius.circular(16),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: AppColors.primaryPurple.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(
                  item.icon,
                  size: 28,
                  color: AppColors.primaryPurple,
                ),
              ),
              const SizedBox(height: 12),
              Text(
                item.title,
                style: Theme.of(context).textTheme.titleSmall?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
                textAlign: TextAlign.center,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class QuickAccessItem {
  final IconData icon;
  final String title;
  final VoidCallback onTap;

  QuickAccessItem({
    required this.icon,
    required this.title,
    required this.onTap,
  });
}

