import 'package:flutter/material.dart';

class AppColors {
  // Primary Colors
  static const Color primaryPurple = Color(0xFF6B46C1);
  static const Color lightPurple = Color(0xFF9F7AEA);
  static const Color darkPurple = Color(0xFF553C9A);
  
  // Navy Blue
  static const Color navyBlue = Color(0xFF1E293B);
  static const Color lightNavy = Color(0xFF334155);
  static const Color darkNavy = Color(0xFF0F172A);
  
  // Neutral Colors
  static const Color white = Color(0xFFFFFFFF);
  static const Color offWhite = Color(0xFFF8FAFC);
  static const Color lightGray = Color(0xFFE2E8F0);
  static const Color mediumGray = Color(0xFF64748B);
  static const Color darkGray = Color(0xFF475569);
  
  // Accent Colors
  static const Color success = Color(0xFF10B981);
  static const Color warning = Color(0xFFF59E0B);
  static const Color error = Color(0xFFEF4444);
  static const Color info = Color(0xFF3B82F6);
  
  // Light Theme Colors
  static const Color lightBackground = white;
  static const Color lightSurface = offWhite;
  static const Color lightCardBackground = white;
  static const Color lightTextPrimary = navyBlue;
  static const Color lightTextSecondary = mediumGray;
  
  // Dark Theme Colors
  static const Color darkBackground = darkNavy;
  static const Color darkSurface = navyBlue;
  static const Color darkCardBackground = lightNavy;
  static const Color darkTextPrimary = white;
  static const Color darkTextSecondary = lightGray;
  
  // Progress Colors
  static const Color progressBackground = lightGray;
  static const Color progressFill = primaryPurple;
  
  // XP Colors
  static const Color xpGold = Color(0xFFFFD700);
  static const Color xpSilver = Color(0xFFC0C0C0);
  static const Color xpBronze = Color(0xFFCD7F32);
}

