import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:uuid/uuid.dart';
import '../models/material_model.dart';
import 'firestore_service.dart';
import 'auth_service.dart';

class DownloadService {
  static const _uuid = Uuid();
  
  static Future<String?> downloadMaterial(
    MaterialModel material,
    AuthService authService,
    {Function(double)? onProgress}
  ) async {
    try {
      // Check if user is authenticated
      if (!authService.isLoggedIn) {
        throw Exception('User must be logged in to download materials');
      }

      // Get app documents directory
      final directory = await getApplicationDocumentsDirectory();
      final downloadsDir = Directory('${directory.path}/downloads');
      
      if (!await downloadsDir.exists()) {
        await downloadsDir.create(recursive: true);
      }

      // Create unique filename to prevent conflicts
      final fileName = '${material.id}_${material.title.replaceAll(RegExp(r'[^\w\s-]'), '')}.pdf';
      final filePath = '${downloadsDir.path}/$fileName';
      
      // Check if file already exists
      final file = File(filePath);
      if (await file.exists()) {
        if (kDebugMode) {
          print('File already exists: $filePath');
        }
        return filePath;
      }

      // Download the file
      final response = await http.get(
        Uri.parse(material.downloadUrl),
        headers: {
          'User-Agent': 'MaterialHubX/1.0',
          'Authorization': 'Bearer ${authService.user?.uid}',
        },
      );

      if (response.statusCode == 200) {
        // Write file to local storage
        await file.writeAsBytes(response.bodyBytes);
        
        // Record download in Firestore
        final download = DownloadModel(
          id: _uuid.v4(),
          userId: authService.user!.uid,
          materialId: material.id,
          downloadedAt: DateTime.now(),
          localPath: filePath,
        );
        
        await FirestoreService.saveDownload(download);
        
        if (kDebugMode) {
          print('Downloaded material: ${material.title} to $filePath');
        }
        
        return filePath;
      } else {
        throw Exception('Failed to download file: ${response.statusCode}');
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error downloading material: $e');
      }
      return null;
    }
  }

  static Future<List<DownloadModel>> getUserDownloads(AuthService authService) async {
    if (!authService.isLoggedIn) return [];
    
    try {
      return await FirestoreService.getUserDownloads(authService.user!.uid);
    } catch (e) {
      if (kDebugMode) {
        print('Error getting user downloads: $e');
      }
      return [];
    }
  }

  static Future<bool> isFileDownloaded(String materialId, AuthService authService) async {
    if (!authService.isLoggedIn) return false;
    
    try {
      final downloads = await getUserDownloads(authService);
      return downloads.any((download) => download.materialId == materialId);
    } catch (e) {
      if (kDebugMode) {
        print('Error checking if file is downloaded: $e');
      }
      return false;
    }
  }

  static Future<String?> getLocalFilePath(String materialId, AuthService authService) async {
    if (!authService.isLoggedIn) return null;
    
    try {
      final downloads = await getUserDownloads(authService);
      final download = downloads.firstWhere(
        (download) => download.materialId == materialId,
        orElse: () => throw Exception('Download not found'),
      );
      
      // Check if file still exists
      final file = File(download.localPath);
      if (await file.exists()) {
        return download.localPath;
      } else {
        // File was deleted, remove from downloads record
        // TODO: Implement download record cleanup
        return null;
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error getting local file path: $e');
      }
      return null;
    }
  }

  static Future<void> deleteDownload(String materialId, AuthService authService) async {
    if (!authService.isLoggedIn) return;
    
    try {
      final localPath = await getLocalFilePath(materialId, authService);
      if (localPath != null) {
        final file = File(localPath);
        if (await file.exists()) {
          await file.delete();
        }
      }
      
      // TODO: Remove from Firestore downloads collection
      if (kDebugMode) {
        print('Deleted download for material: $materialId');
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error deleting download: $e');
      }
    }
  }

  static Future<double> getDownloadedSize() async {
    try {
      final directory = await getApplicationDocumentsDirectory();
      final downloadsDir = Directory('${directory.path}/downloads');
      
      if (!await downloadsDir.exists()) {
        return 0.0;
      }

      double totalSize = 0.0;
      await for (final entity in downloadsDir.list(recursive: true)) {
        if (entity is File) {
          final stat = await entity.stat();
          totalSize += stat.size;
        }
      }
      
      return totalSize;
    } catch (e) {
      if (kDebugMode) {
        print('Error calculating downloaded size: $e');
      }
      return 0.0;
    }
  }

  static String formatFileSize(double bytes) {
    if (bytes < 1024) {
      return '${bytes.toStringAsFixed(0)} B';
    } else if (bytes < 1024 * 1024) {
      return '${(bytes / 1024).toStringAsFixed(1)} KB';
    } else if (bytes < 1024 * 1024 * 1024) {
      return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
    } else {
      return '${(bytes / (1024 * 1024 * 1024)).toStringAsFixed(1)} GB';
    }
  }
}

