import 'package:flutter/foundation.dart';
import 'package:flutter_windowmanager/flutter_windowmanager.dart';
import 'dart:io';

class SecurityService {
  static bool _isProtectionEnabled = false;
  
  static bool get isProtectionEnabled => _isProtectionEnabled;

  /// Initialize security protection
  static Future<void> initialize() async {
    try {
      if (kDebugMode) {
        print('Security service initialized');
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error initializing security service: $e');
      }
    }
  }

  /// Enable screenshot and screen recording protection
  static Future<void> enableProtection() async {
    if (_isProtectionEnabled) return;
    
    try {
      // Disable screenshots and screen recording on Android
      if (!kIsWeb && Platform.isAndroid) {
        await FlutterWindowManager.addFlags(FlutterWindowManager.FLAG_SECURE);
      }

      _isProtectionEnabled = true;
      
      if (kDebugMode) {
        print('Security protection enabled');
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error enabling security protection: $e');
      }
    }
  }

  /// Disable screenshot and screen recording protection
  static Future<void> disableProtection() async {
    if (!_isProtectionEnabled) return;
    
    try {
      // Re-enable screenshots and screen recording on Android
      if (!kIsWeb && Platform.isAndroid) {
        await FlutterWindowManager.clearFlags(FlutterWindowManager.FLAG_SECURE);
      }

      _isProtectionEnabled = false;
      
      if (kDebugMode) {
        print('Security protection disabled');
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error disabling security protection: $e');
      }
    }
  }

  /// Show security warning to user
  static void _showSecurityWarning() {
    // This would typically show a dialog or snackbar
    // For now, we'll just log it
    if (kDebugMode) {
      print('Security Warning: Screenshot/Screen recording is not allowed');
    }
  }

  /// Log security violation
  static void _logSecurityViolation(String violationType) {
    // In a real app, this would log to analytics or security monitoring
    if (kDebugMode) {
      print('Security violation logged: $violationType at ${DateTime.now()}');
    }
  }

  /// Check if device is rooted/jailbroken (basic check)
  static Future<bool> isDeviceCompromised() async {
    try {
      // Basic root detection for Android
      if (!kIsWeb && Platform.isAndroid) {
        // Check for common root indicators
        const rootPaths = [
          '/system/app/Superuser.apk',
          '/sbin/su',
          '/system/bin/su',
          '/system/xbin/su',
          '/data/local/xbin/su',
          '/data/local/bin/su',
          '/system/sd/xbin/su',
          '/system/bin/failsafe/su',
          '/data/local/su',
        ];

        // This is a simplified check - in production, use a proper root detection library
        for (final path in rootPaths) {
          try {
            final file = File(path);
            if (await file.exists()) {
              return true;
            }
          } catch (e) {
            // Path doesn't exist or can't be accessed
          }
        }
      }
      
      return false;
    } catch (e) {
      if (kDebugMode) {
        print('Error checking device compromise: $e');
      }
      return false;
    }
  }

  /// Prevent app from running in debug mode in production
  static void preventDebugging() {
    if (kDebugMode) {
      // In production, you might want to exit the app if debugging is detected
      if (kDebugMode) {
        print('Debug mode detected - this would prevent app execution in production');
      }
    }
  }

  /// Obfuscate sensitive data in memory
  static String obfuscateString(String input) {
    if (input.isEmpty) return input;
    
    final buffer = StringBuffer();
    for (int i = 0; i < input.length; i++) {
      if (i < 2 || i >= input.length - 2) {
        buffer.write(input[i]);
      } else {
        buffer.write('*');
      }
    }
    return buffer.toString();
  }

  /// Dispose of security service
  static void dispose() {
    try {
      _isProtectionEnabled = false;
      
      if (kDebugMode) {
        print('Security service disposed');
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error disposing security service: $e');
      }
    }
  }
}

