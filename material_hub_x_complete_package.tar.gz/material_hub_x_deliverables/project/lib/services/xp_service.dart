import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:async';
import 'auth_service.dart';
import 'firestore_service.dart';

class XPService extends ChangeNotifier {
  int _currentXP = 0;
  int _currentRank = 999;
  DateTime? _lastActiveTime;
  Timer? _xpTimer;
  AuthService? _authService;
  
  int get currentXP => _currentXP;
  int get currentRank => _currentRank;
  
  XPService() {
    _loadXPData();
    _startXPTimer();
  }

  void setAuthService(AuthService authService) {
    _authService = authService;
    if (_authService?.isLoggedIn == true) {
      _syncWithFirebase();
    }
  }

  Future<void> _loadXPData() async {
    final prefs = await SharedPreferences.getInstance();
    _currentXP = prefs.getInt('current_xp') ?? 0;
    _currentRank = prefs.getInt('current_rank') ?? 999;
    
    final lastActiveString = prefs.getString('last_active_time');
    if (lastActiveString != null) {
      _lastActiveTime = DateTime.parse(lastActiveString);
    }
    
    notifyListeners();
  }

  Future<void> _saveXPData() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('current_xp', _currentXP);
    await prefs.setInt('current_rank', _currentRank);
    await prefs.setString('last_active_time', DateTime.now().toIso8601String());
  }

  Future<void> _syncWithFirebase() async {
    if (_authService?.isLoggedIn != true) return;
    
    try {
      // Get user data from Firebase
      final userModel = _authService!.userModel;
      if (userModel != null) {
        _currentXP = userModel.xp;
        _currentRank = userModel.rank;
        notifyListeners();
        await _saveXPData();
      }
      
      // Update rank based on leaderboard
      await _updateRankFromLeaderboard();
    } catch (e) {
      if (kDebugMode) {
        print('Error syncing XP with Firebase: $e');
      }
    }
  }

  Future<void> _updateRankFromLeaderboard() async {
    try {
      final leaderboard = await FirestoreService.getLeaderboard();
      
      // Find user's rank in the leaderboard
      int newRank = 999;
      for (int i = 0; i < leaderboard.length; i++) {
        if (leaderboard[i].uid == _authService?.user?.uid) {
          newRank = i + 1;
          break;
        }
      }
      
      if (newRank != _currentRank) {
        _currentRank = newRank;
        
        // Update in Firebase
        if (_authService?.isLoggedIn == true) {
          await _authService!.updateXP(_currentXP, _currentRank);
        }
        
        notifyListeners();
        await _saveXPData();
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error updating rank from leaderboard: $e');
      }
    }
  }

  void _startXPTimer() {
    _xpTimer = Timer.periodic(const Duration(minutes: 2), (timer) {
      _addXP(1); // 1 XP every 2 minutes
    });
  }

  Future<void> _addXP(int xp) async {
    _currentXP += xp;
    _updateRank();
    await _saveXPData();
    
    // Update in Firebase if user is logged in
    if (_authService?.isLoggedIn == true) {
      await _authService!.updateXP(_currentXP, _currentRank);
    }
    
    notifyListeners();
  }

  void _updateRank() {
    // Simple rank calculation based on XP
    // In a real app, this would be calculated based on all users' XP
    if (_currentXP >= 1000) {
      _currentRank = 1;
    } else if (_currentXP >= 500) {
      _currentRank = 10;
    } else if (_currentXP >= 250) {
      _currentRank = 50;
    } else if (_currentXP >= 100) {
      _currentRank = 100;
    } else {
      _currentRank = 999;
    }
  }

  // Award XP for specific actions
  Future<void> awardXP(int xp, String reason) async {
    await _addXP(xp);
    // TODO: Show XP gained notification
    if (kDebugMode) {
      print('Awarded $xp XP for $reason. Total: $_currentXP XP');
    }
  }

  // Award XP for completing tests
  Future<void> completeTest(int score, int totalQuestions) async {
    final percentage = (score / totalQuestions) * 100;
    int xpToAward = 0;
    
    if (percentage >= 90) {
      xpToAward = 50;
    } else if (percentage >= 80) {
      xpToAward = 40;
    } else if (percentage >= 70) {
      xpToAward = 30;
    } else if (percentage >= 60) {
      xpToAward = 20;
    } else {
      xpToAward = 10;
    }
    
    await awardXP(xpToAward, 'Completing test with $percentage% score');
  }

  // Award XP for daily login
  Future<void> dailyLogin() async {
    final now = DateTime.now();
    if (_lastActiveTime == null || 
        now.difference(_lastActiveTime!).inDays >= 1) {
      await awardXP(5, 'Daily login bonus');
    }
  }

  // Refresh data from Firebase
  Future<void> refreshFromFirebase() async {
    await _syncWithFirebase();
  }

  @override
  void dispose() {
    _xpTimer?.cancel();
    super.dispose();
  }
}

