import 'package:flutter/foundation.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/user_model.dart';

class AuthService extends ChangeNotifier {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  
  User? _user;
  UserModel? _userModel;
  bool _isLoading = false;

  User? get user => _user;
  UserModel? get userModel => _userModel;
  bool get isLoggedIn => _user != null;
  bool get isLoading => _isLoading;
  String? get userEmail => _user?.email;
  String? get userName => _userModel?.name;
  String? get selectedInstitute => _userModel?.selectedInstitute;

  AuthService() {
    _auth.authStateChanges().listen(_onAuthStateChanged);
  }

  Future<void> _onAuthStateChanged(User? user) async {
    _user = user;
    if (user != null) {
      await _loadUserModel();
    } else {
      _userModel = null;
    }
    notifyListeners();
  }

  Future<void> _loadUserModel() async {
    if (_user == null) return;
    
    try {
      final doc = await _firestore.collection('users').doc(_user!.uid).get();
      if (doc.exists) {
        _userModel = UserModel.fromMap(doc.data()!);
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error loading user model: $e');
      }
    }
  }

  Future<bool> login(String email, String password) async {
    try {
      _isLoading = true;
      notifyListeners();
      
      final credential = await _auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );
      
      if (credential.user != null) {
        await _updateLastActiveTime();
        return true;
      }
      return false;
    } on FirebaseAuthException catch (e) {
      if (kDebugMode) {
        print('Login error: ${e.message}');
      }
      return false;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<bool> signup(String email, String password, String name) async {
    try {
      _isLoading = true;
      notifyListeners();
      
      final credential = await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );
      
      if (credential.user != null) {
        // Create user document in Firestore
        final userModel = UserModel(
          uid: credential.user!.uid,
          email: email,
          name: name,
          createdAt: DateTime.now(),
          lastActiveAt: DateTime.now(),
        );
        
        await _firestore
            .collection('users')
            .doc(credential.user!.uid)
            .set(userModel.toMap());
        
        _userModel = userModel;
        return true;
      }
      return false;
    } on FirebaseAuthException catch (e) {
      if (kDebugMode) {
        print('Signup error: ${e.message}');
      }
      return false;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> logout() async {
    await _auth.signOut();
    _user = null;
    _userModel = null;
    notifyListeners();
  }

  Future<void> setSelectedInstitute(String institute) async {
    if (_user == null || _userModel == null) return;
    
    try {
      final updatedUser = _userModel!.copyWith(selectedInstitute: institute);
      
      await _firestore
          .collection('users')
          .doc(_user!.uid)
          .update({'selectedInstitute': institute});
      
      _userModel = updatedUser;
      notifyListeners();
    } catch (e) {
      if (kDebugMode) {
        print('Error updating institute: $e');
      }
    }
  }

  Future<void> updateXP(int newXP, int newRank) async {
    if (_user == null || _userModel == null) return;
    
    try {
      final updatedUser = _userModel!.copyWith(xp: newXP, rank: newRank);
      
      await _firestore.collection('users').doc(_user!.uid).update({
        'xp': newXP,
        'rank': newRank,
        'lastActiveAt': DateTime.now().toIso8601String(),
      });
      
      _userModel = updatedUser;
      notifyListeners();
    } catch (e) {
      if (kDebugMode) {
        print('Error updating XP: $e');
      }
    }
  }

  Future<void> _updateLastActiveTime() async {
    if (_user == null) return;
    
    try {
      await _firestore.collection('users').doc(_user!.uid).update({
        'lastActiveAt': DateTime.now().toIso8601String(),
      });
    } catch (e) {
      if (kDebugMode) {
        print('Error updating last active time: $e');
      }
    }
  }

  // Check if user is authenticated
  Future<void> checkAuthState() async {
    // Firebase Auth automatically handles state changes
    // This method is kept for compatibility
  }
}

