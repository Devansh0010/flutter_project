import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import '../models/user_model.dart';
import '../models/test_model.dart';
import '../models/material_model.dart';

class FirestoreService {
  static final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // User operations
  static Future<void> createUser(UserModel user) async {
    try {
      await _firestore.collection('users').doc(user.uid).set(user.toMap());
    } catch (e) {
      if (kDebugMode) {
        print('Error creating user: $e');
      }
      rethrow;
    }
  }

  static Future<UserModel?> getUser(String uid) async {
    try {
      final doc = await _firestore.collection('users').doc(uid).get();
      if (doc.exists) {
        return UserModel.fromMap(doc.data()!);
      }
      return null;
    } catch (e) {
      if (kDebugMode) {
        print('Error getting user: $e');
      }
      return null;
    }
  }

  static Future<void> updateUser(String uid, Map<String, dynamic> data) async {
    try {
      await _firestore.collection('users').doc(uid).update(data);
    } catch (e) {
      if (kDebugMode) {
        print('Error updating user: $e');
      }
      rethrow;
    }
  }

  // Leaderboard operations
  static Future<List<UserModel>> getLeaderboard({int limit = 50}) async {
    try {
      final query = await _firestore
          .collection('users')
          .orderBy('xp', descending: true)
          .limit(limit)
          .get();

      return query.docs
          .map((doc) => UserModel.fromMap(doc.data()))
          .toList();
    } catch (e) {
      if (kDebugMode) {
        print('Error getting leaderboard: $e');
      }
      return [];
    }
  }

  // Test operations
  static Future<List<TestModel>> getTests({
    String? institute,
    String? subject,
    String? difficulty,
  }) async {
    try {
      Query query = _firestore.collection('tests').where('isActive', isEqualTo: true);

      if (institute != null) {
        query = query.where('institute', isEqualTo: institute);
      }
      if (subject != null) {
        query = query.where('subject', isEqualTo: subject);
      }
      if (difficulty != null) {
        query = query.where('difficulty', isEqualTo: difficulty);
      }

      final snapshot = await query.get();
      return snapshot.docs
          .map((doc) => TestModel.fromMap(doc.data() as Map<String, dynamic>))
          .toList();
    } catch (e) {
      if (kDebugMode) {
        print('Error getting tests: $e');
      }
      return [];
    }
  }

  static Future<TestModel?> getTest(String testId) async {
    try {
      final doc = await _firestore.collection('tests').doc(testId).get();
      if (doc.exists) {
        return TestModel.fromMap(doc.data()!);
      }
      return null;
    } catch (e) {
      if (kDebugMode) {
        print('Error getting test: $e');
      }
      return null;
    }
  }

  static Future<void> saveTestResult(TestResultModel result) async {
    try {
      await _firestore.collection('test_results').doc(result.id).set(result.toMap());
    } catch (e) {
      if (kDebugMode) {
        print('Error saving test result: $e');
      }
      rethrow;
    }
  }

  static Future<List<TestResultModel>> getUserTestResults(String userId) async {
    try {
      final query = await _firestore
          .collection('test_results')
          .where('userId', isEqualTo: userId)
          .orderBy('completedAt', descending: true)
          .get();

      return query.docs
          .map((doc) => TestResultModel.fromMap(doc.data()))
          .toList();
    } catch (e) {
      if (kDebugMode) {
        print('Error getting user test results: $e');
      }
      return [];
    }
  }

  // Material operations
  static Future<List<MaterialModel>> getMaterials({
    String? institute,
    String? subject,
    String? type,
  }) async {
    try {
      Query query = _firestore.collection('materials');

      if (institute != null) {
        query = query.where('institute', isEqualTo: institute);
      }
      if (subject != null) {
        query = query.where('subject', isEqualTo: subject);
      }
      if (type != null) {
        query = query.where('type', isEqualTo: type);
      }

      final snapshot = await query.orderBy('uploadedAt', descending: true).get();
      return snapshot.docs
          .map((doc) => MaterialModel.fromMap(doc.data() as Map<String, dynamic>))
          .toList();
    } catch (e) {
      if (kDebugMode) {
        print('Error getting materials: $e');
      }
      return [];
    }
  }

  static Future<void> saveDownload(DownloadModel download) async {
    try {
      await _firestore.collection('downloads').doc(download.id).set(download.toMap());
    } catch (e) {
      if (kDebugMode) {
        print('Error saving download: $e');
      }
      rethrow;
    }
  }

  static Future<List<DownloadModel>> getUserDownloads(String userId) async {
    try {
      final query = await _firestore
          .collection('downloads')
          .where('userId', isEqualTo: userId)
          .orderBy('downloadedAt', descending: true)
          .get();

      return query.docs
          .map((doc) => DownloadModel.fromMap(doc.data()))
          .toList();
    } catch (e) {
      if (kDebugMode) {
        print('Error getting user downloads: $e');
      }
      return [];
    }
  }

  // Doubt operations
  static Future<void> createDoubt(DoubtModel doubt) async {
    try {
      await _firestore.collection('doubts').doc(doubt.id).set(doubt.toMap());
    } catch (e) {
      if (kDebugMode) {
        print('Error creating doubt: $e');
      }
      rethrow;
    }
  }

  static Future<List<DoubtModel>> getUserDoubts(String userId) async {
    try {
      final query = await _firestore
          .collection('doubts')
          .where('userId', isEqualTo: userId)
          .orderBy('createdAt', descending: true)
          .get();

      return query.docs
          .map((doc) => DoubtModel.fromMap(doc.data()))
          .toList();
    } catch (e) {
      if (kDebugMode) {
        print('Error getting user doubts: $e');
      }
      return [];
    }
  }

  static Future<void> addDoubtReply(String doubtId, DoubtReplyModel reply) async {
    try {
      await _firestore.collection('doubts').doc(doubtId).update({
        'replies': FieldValue.arrayUnion([reply.toMap()]),
      });
    } catch (e) {
      if (kDebugMode) {
        print('Error adding doubt reply: $e');
      }
      rethrow;
    }
  }

  // Batch operations for seeding data
  static Future<void> seedSampleData() async {
    try {
      final batch = _firestore.batch();

      // Sample tests
      final sampleTests = [
        TestModel(
          id: 'test_1',
          title: 'Physics - Mechanics Mock Test',
          description: 'Comprehensive test covering Newton\'s laws and motion',
          institute: 'ARJUNA JEE 2026',
          subject: 'Physics',
          difficulty: 'Medium',
          duration: 60,
          totalQuestions: 30,
          questions: _generateSampleQuestions(),
          createdAt: DateTime.now(),
        ),
        TestModel(
          id: 'test_2',
          title: 'Chemistry - Organic Chemistry Quiz',
          description: 'Test your knowledge of organic reactions',
          institute: 'PHOENIX NEET 2026',
          subject: 'Chemistry',
          difficulty: 'Hard',
          duration: 45,
          totalQuestions: 25,
          questions: _generateSampleQuestions(),
          createdAt: DateTime.now(),
        ),
      ];

      for (final test in sampleTests) {
        batch.set(_firestore.collection('tests').doc(test.id), test.toMap());
      }

      // Sample materials
      final sampleMaterials = [
        MaterialModel(
          id: 'material_1',
          title: 'Physics Formula Sheet',
          description: 'Complete formula sheet for JEE Physics',
          institute: 'ARJUNA JEE 2026',
          subject: 'Physics',
          type: 'pdf',
          downloadUrl: 'https://example.com/physics_formulas.pdf',
          fileSize: 2048000,
          uploadedAt: DateTime.now(),
          tags: ['formulas', 'reference', 'jee'],
        ),
        MaterialModel(
          id: 'material_2',
          title: 'Organic Chemistry Notes',
          description: 'Detailed notes on organic chemistry reactions',
          institute: 'PHOENIX NEET 2026',
          subject: 'Chemistry',
          type: 'pdf',
          downloadUrl: 'https://example.com/organic_chemistry.pdf',
          fileSize: 5120000,
          uploadedAt: DateTime.now(),
          tags: ['notes', 'organic', 'neet'],
        ),
      ];

      for (final material in sampleMaterials) {
        batch.set(_firestore.collection('materials').doc(material.id), material.toMap());
      }

      await batch.commit();
      
      if (kDebugMode) {
        print('Sample data seeded successfully');
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error seeding sample data: $e');
      }
    }
  }

  static List<QuestionModel> _generateSampleQuestions() {
    return [
      QuestionModel(
        id: 'q1',
        question: 'What is the acceleration due to gravity on Earth?',
        options: ['9.8 m/s²', '10 m/s²', '8.9 m/s²', '11 m/s²'],
        correctAnswer: 0,
        explanation: 'The standard acceleration due to gravity on Earth is approximately 9.8 m/s².',
        marks: 1,
      ),
      QuestionModel(
        id: 'q2',
        question: 'Which of the following is a vector quantity?',
        options: ['Speed', 'Distance', 'Velocity', 'Time'],
        correctAnswer: 2,
        explanation: 'Velocity is a vector quantity as it has both magnitude and direction.',
        marks: 1,
      ),
    ];
  }
}

