class TestModel {
  final String id;
  final String title;
  final String description;
  final String institute;
  final String subject;
  final String difficulty;
  final int duration; // in minutes
  final int totalQuestions;
  final List<QuestionModel> questions;
  final DateTime createdAt;
  final bool isActive;

  TestModel({
    required this.id,
    required this.title,
    required this.description,
    required this.institute,
    required this.subject,
    required this.difficulty,
    required this.duration,
    required this.totalQuestions,
    required this.questions,
    required this.createdAt,
    this.isActive = true,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'title': title,
      'description': description,
      'institute': institute,
      'subject': subject,
      'difficulty': difficulty,
      'duration': duration,
      'totalQuestions': totalQuestions,
      'questions': questions.map((q) => q.toMap()).toList(),
      'createdAt': createdAt.toIso8601String(),
      'isActive': isActive,
    };
  }

  factory TestModel.fromMap(Map<String, dynamic> map) {
    return TestModel(
      id: map['id'] ?? '',
      title: map['title'] ?? '',
      description: map['description'] ?? '',
      institute: map['institute'] ?? '',
      subject: map['subject'] ?? '',
      difficulty: map['difficulty'] ?? '',
      duration: map['duration']?.toInt() ?? 0,
      totalQuestions: map['totalQuestions']?.toInt() ?? 0,
      questions: List<QuestionModel>.from(
        map['questions']?.map((q) => QuestionModel.fromMap(q)) ?? [],
      ),
      createdAt: DateTime.parse(map['createdAt']),
      isActive: map['isActive'] ?? true,
    );
  }
}

class QuestionModel {
  final String id;
  final String question;
  final List<String> options;
  final int correctAnswer; // index of correct option
  final String explanation;
  final int marks;

  QuestionModel({
    required this.id,
    required this.question,
    required this.options,
    required this.correctAnswer,
    required this.explanation,
    this.marks = 1,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'question': question,
      'options': options,
      'correctAnswer': correctAnswer,
      'explanation': explanation,
      'marks': marks,
    };
  }

  factory QuestionModel.fromMap(Map<String, dynamic> map) {
    return QuestionModel(
      id: map['id'] ?? '',
      question: map['question'] ?? '',
      options: List<String>.from(map['options'] ?? []),
      correctAnswer: map['correctAnswer']?.toInt() ?? 0,
      explanation: map['explanation'] ?? '',
      marks: map['marks']?.toInt() ?? 1,
    );
  }
}

class TestResultModel {
  final String id;
  final String userId;
  final String testId;
  final int score;
  final int totalQuestions;
  final int timeTaken; // in seconds
  final Map<String, int> answers; // questionId -> selectedOption
  final DateTime completedAt;
  final int xpEarned;

  TestResultModel({
    required this.id,
    required this.userId,
    required this.testId,
    required this.score,
    required this.totalQuestions,
    required this.timeTaken,
    required this.answers,
    required this.completedAt,
    required this.xpEarned,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'userId': userId,
      'testId': testId,
      'score': score,
      'totalQuestions': totalQuestions,
      'timeTaken': timeTaken,
      'answers': answers,
      'completedAt': completedAt.toIso8601String(),
      'xpEarned': xpEarned,
    };
  }

  factory TestResultModel.fromMap(Map<String, dynamic> map) {
    return TestResultModel(
      id: map['id'] ?? '',
      userId: map['userId'] ?? '',
      testId: map['testId'] ?? '',
      score: map['score']?.toInt() ?? 0,
      totalQuestions: map['totalQuestions']?.toInt() ?? 0,
      timeTaken: map['timeTaken']?.toInt() ?? 0,
      answers: Map<String, int>.from(map['answers'] ?? {}),
      completedAt: DateTime.parse(map['completedAt']),
      xpEarned: map['xpEarned']?.toInt() ?? 0,
    );
  }

  double get percentage => (score / totalQuestions) * 100;
}

