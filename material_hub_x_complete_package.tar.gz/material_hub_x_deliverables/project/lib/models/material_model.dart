class MaterialModel {
  final String id;
  final String title;
  final String description;
  final String institute;
  final String subject;
  final String type; // 'pdf', 'video', 'notes', 'assignment'
  final String downloadUrl;
  final String? thumbnailUrl;
  final int fileSize; // in bytes
  final DateTime uploadedAt;
  final bool isPremium;
  final List<String> tags;

  MaterialModel({
    required this.id,
    required this.title,
    required this.description,
    required this.institute,
    required this.subject,
    required this.type,
    required this.downloadUrl,
    this.thumbnailUrl,
    required this.fileSize,
    required this.uploadedAt,
    this.isPremium = false,
    this.tags = const [],
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'title': title,
      'description': description,
      'institute': institute,
      'subject': subject,
      'type': type,
      'downloadUrl': downloadUrl,
      'thumbnailUrl': thumbnailUrl,
      'fileSize': fileSize,
      'uploadedAt': uploadedAt.toIso8601String(),
      'isPremium': isPremium,
      'tags': tags,
    };
  }

  factory MaterialModel.fromMap(Map<String, dynamic> map) {
    return MaterialModel(
      id: map['id'] ?? '',
      title: map['title'] ?? '',
      description: map['description'] ?? '',
      institute: map['institute'] ?? '',
      subject: map['subject'] ?? '',
      type: map['type'] ?? '',
      downloadUrl: map['downloadUrl'] ?? '',
      thumbnailUrl: map['thumbnailUrl'],
      fileSize: map['fileSize']?.toInt() ?? 0,
      uploadedAt: DateTime.parse(map['uploadedAt']),
      isPremium: map['isPremium'] ?? false,
      tags: List<String>.from(map['tags'] ?? []),
    );
  }

  String get formattedFileSize {
    if (fileSize < 1024) {
      return '$fileSize B';
    } else if (fileSize < 1024 * 1024) {
      return '${(fileSize / 1024).toStringAsFixed(1)} KB';
    } else {
      return '${(fileSize / (1024 * 1024)).toStringAsFixed(1)} MB';
    }
  }
}

class DownloadModel {
  final String id;
  final String userId;
  final String materialId;
  final DateTime downloadedAt;
  final String localPath;

  DownloadModel({
    required this.id,
    required this.userId,
    required this.materialId,
    required this.downloadedAt,
    required this.localPath,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'userId': userId,
      'materialId': materialId,
      'downloadedAt': downloadedAt.toIso8601String(),
      'localPath': localPath,
    };
  }

  factory DownloadModel.fromMap(Map<String, dynamic> map) {
    return DownloadModel(
      id: map['id'] ?? '',
      userId: map['userId'] ?? '',
      materialId: map['materialId'] ?? '',
      downloadedAt: DateTime.parse(map['downloadedAt']),
      localPath: map['localPath'] ?? '',
    );
  }
}

class DoubtModel {
  final String id;
  final String userId;
  final String title;
  final String description;
  final String subject;
  final String? imageUrl;
  final DateTime createdAt;
  final bool isResolved;
  final List<DoubtReplyModel> replies;

  DoubtModel({
    required this.id,
    required this.userId,
    required this.title,
    required this.description,
    required this.subject,
    this.imageUrl,
    required this.createdAt,
    this.isResolved = false,
    this.replies = const [],
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'userId': userId,
      'title': title,
      'description': description,
      'subject': subject,
      'imageUrl': imageUrl,
      'createdAt': createdAt.toIso8601String(),
      'isResolved': isResolved,
      'replies': replies.map((r) => r.toMap()).toList(),
    };
  }

  factory DoubtModel.fromMap(Map<String, dynamic> map) {
    return DoubtModel(
      id: map['id'] ?? '',
      userId: map['userId'] ?? '',
      title: map['title'] ?? '',
      description: map['description'] ?? '',
      subject: map['subject'] ?? '',
      imageUrl: map['imageUrl'],
      createdAt: DateTime.parse(map['createdAt']),
      isResolved: map['isResolved'] ?? false,
      replies: List<DoubtReplyModel>.from(
        map['replies']?.map((r) => DoubtReplyModel.fromMap(r)) ?? [],
      ),
    );
  }
}

class DoubtReplyModel {
  final String id;
  final String doubtId;
  final String userId;
  final String userName;
  final String reply;
  final DateTime createdAt;
  final bool isTeacher;

  DoubtReplyModel({
    required this.id,
    required this.doubtId,
    required this.userId,
    required this.userName,
    required this.reply,
    required this.createdAt,
    this.isTeacher = false,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'doubtId': doubtId,
      'userId': userId,
      'userName': userName,
      'reply': reply,
      'createdAt': createdAt.toIso8601String(),
      'isTeacher': isTeacher,
    };
  }

  factory DoubtReplyModel.fromMap(Map<String, dynamic> map) {
    return DoubtReplyModel(
      id: map['id'] ?? '',
      doubtId: map['doubtId'] ?? '',
      userId: map['userId'] ?? '',
      userName: map['userName'] ?? '',
      reply: map['reply'] ?? '',
      createdAt: DateTime.parse(map['createdAt']),
      isTeacher: map['isTeacher'] ?? false,
    );
  }
}

