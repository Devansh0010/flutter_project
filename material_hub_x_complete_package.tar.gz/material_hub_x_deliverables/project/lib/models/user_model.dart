class UserModel {
  final String uid;
  final String email;
  final String name;
  final String? selectedInstitute;
  final String? selectedClass;
  final int xp;
  final int rank;
  final DateTime createdAt;
  final DateTime lastActiveAt;
  final Map<String, dynamic> preferences;

  UserModel({
    required this.uid,
    required this.email,
    required this.name,
    this.selectedInstitute,
    this.selectedClass,
    this.xp = 0,
    this.rank = 999,
    required this.createdAt,
    required this.lastActiveAt,
    this.preferences = const {},
  });

  Map<String, dynamic> toMap() {
    return {
      'uid': uid,
      'email': email,
      'name': name,
      'selectedInstitute': selectedInstitute,
      'selectedClass': selectedClass,
      'xp': xp,
      'rank': rank,
      'createdAt': createdAt.toIso8601String(),
      'lastActiveAt': lastActiveAt.toIso8601String(),
      'preferences': preferences,
    };
  }

  factory UserModel.fromMap(Map<String, dynamic> map) {
    return UserModel(
      uid: map['uid'] ?? '',
      email: map['email'] ?? '',
      name: map['name'] ?? '',
      selectedInstitute: map['selectedInstitute'],
      selectedClass: map['selectedClass'],
      xp: map['xp']?.toInt() ?? 0,
      rank: map['rank']?.toInt() ?? 999,
      createdAt: DateTime.parse(map['createdAt']),
      lastActiveAt: DateTime.parse(map['lastActiveAt']),
      preferences: Map<String, dynamic>.from(map['preferences'] ?? {}),
    );
  }

  UserModel copyWith({
    String? uid,
    String? email,
    String? name,
    String? selectedInstitute,
    String? selectedClass,
    int? xp,
    int? rank,
    DateTime? createdAt,
    DateTime? lastActiveAt,
    Map<String, dynamic>? preferences,
  }) {
    return UserModel(
      uid: uid ?? this.uid,
      email: email ?? this.email,
      name: name ?? this.name,
      selectedInstitute: selectedInstitute ?? this.selectedInstitute,
      selectedClass: selectedClass ?? this.selectedClass,
      xp: xp ?? this.xp,
      rank: rank ?? this.rank,
      createdAt: createdAt ?? this.createdAt,
      lastActiveAt: lastActiveAt ?? this.lastActiveAt,
      preferences: preferences ?? this.preferences,
    );
  }
}

