import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/xp_service.dart';
import '../constants/app_colors.dart';

class LeaderboardScreen extends StatelessWidget {
  const LeaderboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Leaderboard'),
        backgroundColor: Colors.transparent,
        elevation: 0,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () {
              // TODO: Refresh leaderboard data
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // Current User Rank Card
            _buildCurrentUserCard(context),
            const SizedBox(height: 24),
            
            // Top 3 Podium
            _buildTopThreePodium(),
            const SizedBox(height: 24),
            
            // Leaderboard List
            _buildLeaderboardList(context),
          ],
        ),
      ),
    );
  }

  Widget _buildCurrentUserCard(BuildContext context) {
    return Consumer<XPService>(
      builder: (context, xpService, child) {
        return Card(
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Row(
              children: [
                Container(
                  width: 60,
                  height: 60,
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [AppColors.primaryPurple, AppColors.lightPurple],
                    ),
                    borderRadius: BorderRadius.circular(30),
                  ),
                  child: const Icon(
                    Icons.person,
                    color: AppColors.white,
                    size: 30,
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Your Rank',
                        style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        '#${xpService.currentRank}',
                        style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                          color: AppColors.primaryPurple,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      'XP',
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: AppColors.mediumGray,
                      ),
                    ),
                    Text(
                      '${xpService.currentXP}',
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildTopThreePodium() {
    final topUsers = [
      LeaderboardUser(rank: 2, name: 'Alex Kumar', xp: 2450, avatar: '👨‍🎓'),
      LeaderboardUser(rank: 1, name: 'Priya Sharma', xp: 2890, avatar: '👩‍🎓'),
      LeaderboardUser(rank: 3, name: 'Rahul Singh', xp: 2120, avatar: '👨‍💻'),
    ];

    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        _buildPodiumCard(topUsers[0], 80),
        _buildPodiumCard(topUsers[1], 100),
        _buildPodiumCard(topUsers[2], 60),
      ],
    );
  }

  Widget _buildPodiumCard(LeaderboardUser user, double height) {
    Color rankColor;
    IconData crownIcon;
    
    switch (user.rank) {
      case 1:
        rankColor = AppColors.xpGold;
        crownIcon = Icons.emoji_events;
        break;
      case 2:
        rankColor = AppColors.xpSilver;
        crownIcon = Icons.emoji_events_outlined;
        break;
      case 3:
        rankColor = AppColors.xpBronze;
        crownIcon = Icons.emoji_events_outlined;
        break;
      default:
        rankColor = AppColors.mediumGray;
        crownIcon = Icons.emoji_events_outlined;
    }

    return Column(
      children: [
        Container(
          width: 80,
          height: 80,
          decoration: BoxDecoration(
            color: rankColor.withOpacity(0.1),
            borderRadius: BorderRadius.circular(40),
            border: Border.all(color: rankColor, width: 3),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                user.avatar,
                style: const TextStyle(fontSize: 24),
              ),
              Icon(
                crownIcon,
                color: rankColor,
                size: 16,
              ),
            ],
          ),
        ),
        const SizedBox(height: 8),
        Container(
          width: 100,
          height: height,
          decoration: BoxDecoration(
            color: rankColor.withOpacity(0.2),
            borderRadius: const BorderRadius.vertical(top: Radius.circular(8)),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                '#${user.rank}',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: rankColor,
                ),
              ),
              Text(
                user.name,
                style: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w500,
                ),
                textAlign: TextAlign.center,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
              Text(
                '${user.xp} XP',
                style: const TextStyle(
                  fontSize: 10,
                  color: AppColors.mediumGray,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildLeaderboardList(BuildContext context) {
    final users = [
      LeaderboardUser(rank: 4, name: 'Anita Patel', xp: 1980, avatar: '👩‍🔬'),
      LeaderboardUser(rank: 5, name: 'Vikram Joshi', xp: 1850, avatar: '👨‍🏫'),
      LeaderboardUser(rank: 6, name: 'Sneha Gupta', xp: 1720, avatar: '👩‍💼'),
      LeaderboardUser(rank: 7, name: 'Arjun Reddy', xp: 1650, avatar: '👨‍🎨'),
      LeaderboardUser(rank: 8, name: 'Kavya Nair', xp: 1580, avatar: '👩‍🎓'),
      LeaderboardUser(rank: 9, name: 'Rohit Mehta', xp: 1520, avatar: '👨‍💻'),
      LeaderboardUser(rank: 10, name: 'Divya Shah', xp: 1450, avatar: '👩‍🔬'),
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Top Performers',
          style: Theme.of(context).textTheme.titleLarge?.copyWith(
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 16),
        ListView.separated(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: users.length,
          separatorBuilder: (context, index) => const SizedBox(height: 8),
          itemBuilder: (context, index) {
            final user = users[index];
            return _buildLeaderboardItem(context, user);
          },
        ),
      ],
    );
  }

  Widget _buildLeaderboardItem(BuildContext context, LeaderboardUser user) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Row(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: AppColors.primaryPurple.withOpacity(0.1),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Center(
                child: Text(
                  '#${user.rank}',
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    color: AppColors.primaryPurple,
                  ),
                ),
              ),
            ),
            const SizedBox(width: 16),
            Container(
              width: 50,
              height: 50,
              decoration: BoxDecoration(
                color: AppColors.lightGray,
                borderRadius: BorderRadius.circular(25),
              ),
              child: Center(
                child: Text(
                  user.avatar,
                  style: const TextStyle(fontSize: 20),
                ),
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    user.name,
                    style: const TextStyle(
                      fontWeight: FontWeight.w600,
                      fontSize: 16,
                    ),
                  ),
                  Text(
                    '${user.xp} XP',
                    style: const TextStyle(
                      color: AppColors.mediumGray,
                      fontSize: 14,
                    ),
                  ),
                ],
              ),
            ),
            if (user.rank <= 3)
              Icon(
                Icons.emoji_events,
                color: user.rank == 1 ? AppColors.xpGold : 
                       user.rank == 2 ? AppColors.xpSilver : AppColors.xpBronze,
              ),
          ],
        ),
      ),
    );
  }
}

class LeaderboardUser {
  final int rank;
  final String name;
  final int xp;
  final String avatar;

  LeaderboardUser({
    required this.rank,
    required this.name,
    required this.xp,
    required this.avatar,
  });
}

