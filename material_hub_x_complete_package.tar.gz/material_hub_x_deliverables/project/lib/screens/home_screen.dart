import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/xp_service.dart';
import '../widgets/preparation_meter_card.dart';
import '../widgets/quick_access_grid.dart';
import '../widgets/explore_section.dart';
import '../widgets/theme_toggle_button.dart';
import '../constants/app_colors.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String selectedClass = '11th - IIT JEE';
  
  final List<String> classOptions = [
    '11th - IIT JEE',
    '12th - IIT JEE',
    '11th - NEET',
    '12th - NEET',
    'UPSC Foundation',
    'UPSC Mains',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Top Section with Class Selector and Navigation
              _buildTopSection(),
              const SizedBox(height: 20),
              
              // XP Display
              _buildXPSection(),
              const SizedBox(height: 20),
              
              // Preparation Meter Card
              const PreparationMeterCard(),
              const SizedBox(height: 24),
              
              // Quick Access Grid
              const QuickAccessGrid(),
              const SizedBox(height: 24),
              
              // Explore Section
              const ExploreSection(),
              const SizedBox(height: 100), // Bottom padding for navigation
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTopSection() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        IconButton(
          onPressed: () {
            // TODO: Open navigation drawer
          },
          icon: const Icon(Icons.menu),
          iconSize: 28,
        ),
        Row(
          children: [
            const ThemeToggleButton(),
            const SizedBox(width: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              decoration: BoxDecoration(
                color: Theme.of(context).cardColor,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: AppColors.lightGray,
                  width: 1,
                ),
              ),
              child: DropdownButtonHideUnderline(
                child: DropdownButton<String>(
                  value: selectedClass,
                  onChanged: (String? newValue) {
                    if (newValue != null) {
                      setState(() {
                        selectedClass = newValue;
                      });
                    }
                  },
                  items: classOptions.map<DropdownMenuItem<String>>((String value) {
                    return DropdownMenuItem<String>(
                      value: value,
                      child: Text(
                        value,
                        style: Theme.of(context).textTheme.titleSmall,
                      ),
                    );
                  }).toList(),
                  icon: const Icon(Icons.keyboard_arrow_down),
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildXPSection() {
    return Consumer<XPService>(
      builder: (context, xpService, child) {
        return Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [AppColors.primaryPurple, AppColors.lightPurple],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Your XP',
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      color: AppColors.white,
                    ),
                  ),
                  Text(
                    '${xpService.currentXP} XP',
                    style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                      color: AppColors.white,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    'Rank',
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      color: AppColors.white,
                    ),
                  ),
                  Text(
                    '#${xpService.currentRank}',
                    style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                      color: AppColors.xpGold,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }
}

