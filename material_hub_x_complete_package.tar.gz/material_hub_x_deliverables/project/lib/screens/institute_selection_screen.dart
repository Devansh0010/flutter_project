import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/auth_service.dart';
import '../constants/app_colors.dart';

class InstituteSelectionScreen extends StatefulWidget {
  const InstituteSelectionScreen({super.key});

  @override
  State<InstituteSelectionScreen> createState() => _InstituteSelectionScreenState();
}

class _InstituteSelectionScreenState extends State<InstituteSelectionScreen> {
  String? selectedInstitute;
  
  final List<Institute> institutes = [
    Institute(
      name: 'ARJUNA JEE 2026',
      description: 'Comprehensive JEE preparation with expert faculty',
      subjects: ['Physics', 'Chemistry', 'Mathematics'],
      logo: '🎯',
      color: AppColors.primaryPurple,
    ),
    Institute(
      name: 'PHOENIX NEET 2026',
      description: 'Medical entrance preparation with proven results',
      subjects: ['Physics', 'Chemistry', 'Biology'],
      logo: '🔥',
      color: AppColors.success,
    ),
    Institute(
      name: 'EAGLE UPSC Foundation',
      description: 'Civil services preparation from basics',
      subjects: ['History', 'Geography', 'Polity', 'Economics'],
      logo: '🦅',
      color: AppColors.info,
    ),
    Institute(
      name: 'TITAN JEE Advanced',
      description: 'Advanced level JEE preparation for toppers',
      subjects: ['Advanced Physics', 'Advanced Chemistry', 'Advanced Math'],
      logo: '⚡',
      color: AppColors.warning,
    ),
    Institute(
      name: 'APEX NEET Plus',
      description: 'NEET preparation with additional competitive exams',
      subjects: ['Physics', 'Chemistry', 'Biology', 'General Knowledge'],
      logo: '🏔️',
      color: AppColors.lightPurple,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Select Institute'),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header Section
            Text(
              'Choose Your Institute',
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Select the institute whose materials you want to access. You can change this later in settings.',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: AppColors.mediumGray,
              ),
            ),
            const SizedBox(height: 24),
            
            // Institute Cards
            ListView.separated(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: institutes.length,
              separatorBuilder: (context, index) => const SizedBox(height: 16),
              itemBuilder: (context, index) {
                final institute = institutes[index];
                return _buildInstituteCard(institute);
              },
            ),
            
            const SizedBox(height: 32),
            
            // Continue Button
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: selectedInstitute != null ? _handleContinue : null,
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                ),
                child: const Text(
                  'Continue',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInstituteCard(Institute institute) {
    final isSelected = selectedInstitute == institute.name;
    
    return Card(
      elevation: isSelected ? 4 : 2,
      child: InkWell(
        onTap: () {
          setState(() {
            selectedInstitute = institute.name;
          });
        },
        borderRadius: BorderRadius.circular(16),
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            border: isSelected 
                ? Border.all(color: institute.color, width: 2)
                : null,
          ),
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      width: 60,
                      height: 60,
                      decoration: BoxDecoration(
                        color: institute.color.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(30),
                      ),
                      child: Center(
                        child: Text(
                          institute.logo,
                          style: const TextStyle(fontSize: 24),
                        ),
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            institute.name,
                            style: Theme.of(context).textTheme.titleLarge?.copyWith(
                              fontWeight: FontWeight.bold,
                              color: isSelected ? institute.color : null,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            institute.description,
                            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                              color: AppColors.mediumGray,
                            ),
                          ),
                        ],
                      ),
                    ),
                    if (isSelected)
                      Container(
                        padding: const EdgeInsets.all(4),
                        decoration: BoxDecoration(
                          color: institute.color,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: const Icon(
                          Icons.check,
                          color: AppColors.white,
                          size: 16,
                        ),
                      ),
                  ],
                ),
                const SizedBox(height: 16),
                
                // Subjects
                Text(
                  'Subjects:',
                  style: Theme.of(context).textTheme.titleSmall?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: institute.subjects.map((subject) {
                    return Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(
                        color: institute.color.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(
                          color: institute.color.withOpacity(0.3),
                        ),
                      ),
                      child: Text(
                        subject,
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          color: institute.color,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    );
                  }).toList(),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _handleContinue() {
    if (selectedInstitute != null) {
      final authService = Provider.of<AuthService>(context, listen: false);
      authService.setSelectedInstitute(selectedInstitute!);
      
      // Navigate to home screen
      Navigator.of(context).pushReplacementNamed('/home');
      
      // Show success message
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Selected $selectedInstitute successfully!'),
          backgroundColor: AppColors.success,
        ),
      );
    }
  }
}

class Institute {
  final String name;
  final String description;
  final List<String> subjects;
  final String logo;
  final Color color;

  Institute({
    required this.name,
    required this.description,
    required this.subjects,
    required this.logo,
    required this.color,
  });
}

