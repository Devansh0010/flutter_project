import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'dart:async';
import '../models/test_model.dart';
import '../services/auth_service.dart';
import '../services/xp_service.dart';
import '../services/security_service.dart';
import '../services/firestore_service.dart';
import '../constants/app_colors.dart';
import 'package:uuid/uuid.dart';

class TestScreen extends StatefulWidget {
  final TestModel test;

  const TestScreen({super.key, required this.test});

  @override
  State<TestScreen> createState() => _TestScreenState();
}

class _TestScreenState extends State<TestScreen> {
  int _currentQuestionIndex = 0;
  final Map<String, int> _answers = {};
  Timer? _timer;
  int _timeRemaining = 0;
  bool _isTestCompleted = false;
  bool _isSubmitting = false;

  @override
  void initState() {
    super.initState();
    _timeRemaining = widget.test.duration * 60; // Convert minutes to seconds
    _startTimer();
    _enableSecurityProtection();
  }

  @override
  void dispose() {
    _timer?.cancel();
    _disableSecurityProtection();
    super.dispose();
  }

  void _startTimer() {
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (_timeRemaining > 0) {
        setState(() {
          _timeRemaining--;
        });
      } else {
        _submitTest();
      }
    });
  }

  void _enableSecurityProtection() async {
    await SecurityService.enableProtection();
  }

  void _disableSecurityProtection() async {
    await SecurityService.disableProtection();
  }

  String _formatTime(int seconds) {
    final hours = seconds ~/ 3600;
    final minutes = (seconds % 3600) ~/ 60;
    final secs = seconds % 60;
    
    if (hours > 0) {
      return '${hours.toString().padLeft(2, '0')}:${minutes.toString().padLeft(2, '0')}:${secs.toString().padLeft(2, '0')}';
    } else {
      return '${minutes.toString().padLeft(2, '0')}:${secs.toString().padLeft(2, '0')}';
    }
  }

  void _selectAnswer(int optionIndex) {
    setState(() {
      _answers[widget.test.questions[_currentQuestionIndex].id] = optionIndex;
    });
  }

  void _nextQuestion() {
    if (_currentQuestionIndex < widget.test.questions.length - 1) {
      setState(() {
        _currentQuestionIndex++;
      });
    }
  }

  void _previousQuestion() {
    if (_currentQuestionIndex > 0) {
      setState(() {
        _currentQuestionIndex--;
      });
    }
  }

  void _goToQuestion(int index) {
    setState(() {
      _currentQuestionIndex = index;
    });
  }

  Future<void> _submitTest() async {
    if (_isSubmitting || _isTestCompleted) return;

    setState(() {
      _isSubmitting = true;
    });

    _timer?.cancel();

    try {
      final authService = Provider.of<AuthService>(context, listen: false);
      final xpService = Provider.of<XPService>(context, listen: false);

      // Calculate score
      int score = 0;
      for (final question in widget.test.questions) {
        final userAnswer = _answers[question.id];
        if (userAnswer != null && userAnswer == question.correctAnswer) {
          score += question.marks;
        }
      }

      // Create test result
      final testResult = TestResultModel(
        id: const Uuid().v4(),
        userId: authService.user!.uid,
        testId: widget.test.id,
        score: score,
        totalQuestions: widget.test.questions.length,
        timeTaken: (widget.test.duration * 60) - _timeRemaining,
        answers: _answers,
        completedAt: DateTime.now(),
        xpEarned: _calculateXPEarned(score, widget.test.questions.length),
      );

      // Save test result
      await FirestoreService.saveTestResult(testResult);

      // Award XP
      await xpService.completeTest(score, widget.test.questions.length);

      setState(() {
        _isTestCompleted = true;
      });

      // Show results
      _showTestResults(testResult);

    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error submitting test: $e'),
          backgroundColor: AppColors.error,
        ),
      );
    } finally {
      setState(() {
        _isSubmitting = false;
      });
    }
  }

  int _calculateXPEarned(int score, int totalQuestions) {
    final percentage = (score / totalQuestions) * 100;
    if (percentage >= 90) return 50;
    if (percentage >= 80) return 40;
    if (percentage >= 70) return 30;
    if (percentage >= 60) return 20;
    return 10;
  }

  void _showTestResults(TestResultModel result) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: const Text('Test Completed!'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('Score: ${result.score}/${result.totalQuestions}'),
            Text('Percentage: ${result.percentage.toStringAsFixed(1)}%'),
            Text('XP Earned: ${result.xpEarned}'),
            Text('Time Taken: ${_formatTime(result.timeTaken)}'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop(); // Close dialog
              Navigator.of(context).pop(); // Go back to previous screen
            },
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_isTestCompleted) {
      return Scaffold(
        appBar: AppBar(
          title: const Text('Test Completed'),
          automaticallyImplyLeading: false,
        ),
        body: const Center(
          child: CircularProgressIndicator(),
        ),
      );
    }

    final currentQuestion = widget.test.questions[_currentQuestionIndex];
    final selectedAnswer = _answers[currentQuestion.id];

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.test.title),
        backgroundColor: AppColors.primaryPurple,
        foregroundColor: AppColors.white,
        actions: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            margin: const EdgeInsets.only(right: 16),
            decoration: BoxDecoration(
              color: _timeRemaining < 300 ? AppColors.error : AppColors.white.withOpacity(0.2),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Text(
              _formatTime(_timeRemaining),
              style: const TextStyle(
                fontWeight: FontWeight.bold,
                color: AppColors.white,
              ),
            ),
          ),
        ],
      ),
      body: Column(
        children: [
          // Progress indicator
          LinearProgressIndicator(
            value: (_currentQuestionIndex + 1) / widget.test.questions.length,
            backgroundColor: AppColors.lightGray,
            valueColor: const AlwaysStoppedAnimation<Color>(AppColors.primaryPurple),
          ),
          
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Question number and info
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Question ${_currentQuestionIndex + 1} of ${widget.test.questions.length}',
                        style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          color: AppColors.mediumGray,
                        ),
                      ),
                      Text(
                        'Marks: ${currentQuestion.marks}',
                        style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          color: AppColors.primaryPurple,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  
                  // Question text
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Text(
                        currentQuestion.question,
                        style: Theme.of(context).textTheme.titleLarge,
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  
                  // Options
                  Expanded(
                    child: ListView.builder(
                      itemCount: currentQuestion.options.length,
                      itemBuilder: (context, index) {
                        final isSelected = selectedAnswer == index;
                        return Card(
                          margin: const EdgeInsets.only(bottom: 8),
                          child: InkWell(
                            onTap: () => _selectAnswer(index),
                            borderRadius: BorderRadius.circular(16),
                            child: Container(
                              padding: const EdgeInsets.all(16),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(16),
                                border: isSelected 
                                    ? Border.all(color: AppColors.primaryPurple, width: 2)
                                    : null,
                                color: isSelected 
                                    ? AppColors.primaryPurple.withOpacity(0.1)
                                    : null,
                              ),
                              child: Row(
                                children: [
                                  Container(
                                    width: 24,
                                    height: 24,
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      border: Border.all(
                                        color: isSelected 
                                            ? AppColors.primaryPurple 
                                            : AppColors.mediumGray,
                                        width: 2,
                                      ),
                                      color: isSelected 
                                          ? AppColors.primaryPurple 
                                          : Colors.transparent,
                                    ),
                                    child: isSelected
                                        ? const Icon(
                                            Icons.check,
                                            size: 16,
                                            color: AppColors.white,
                                          )
                                        : null,
                                  ),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: Text(
                                      '${String.fromCharCode(65 + index)}. ${currentQuestion.options[index]}',
                                      style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                                        color: isSelected 
                                            ? AppColors.primaryPurple 
                                            : null,
                                        fontWeight: isSelected 
                                            ? FontWeight.w600 
                                            : null,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
          ),
          
          // Navigation buttons
          Container(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                if (_currentQuestionIndex > 0)
                  Expanded(
                    child: OutlinedButton(
                      onPressed: _previousQuestion,
                      child: const Text('Previous'),
                    ),
                  ),
                if (_currentQuestionIndex > 0) const SizedBox(width: 16),
                Expanded(
                  child: ElevatedButton(
                    onPressed: _currentQuestionIndex < widget.test.questions.length - 1
                        ? _nextQuestion
                        : _isSubmitting ? null : _submitTest,
                    child: _isSubmitting
                        ? const SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              valueColor: AlwaysStoppedAnimation<Color>(AppColors.white),
                            ),
                          )
                        : Text(_currentQuestionIndex < widget.test.questions.length - 1
                            ? 'Next'
                            : 'Submit Test'),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
      
      // Question navigation drawer
      endDrawer: Drawer(
        child: Column(
          children: [
            const DrawerHeader(
              decoration: BoxDecoration(
                color: AppColors.primaryPurple,
              ),
              child: Center(
                child: Text(
                  'Question Navigation',
                  style: TextStyle(
                    color: AppColors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
            Expanded(
              child: GridView.builder(
                padding: const EdgeInsets.all(16),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 5,
                  crossAxisSpacing: 8,
                  mainAxisSpacing: 8,
                ),
                itemCount: widget.test.questions.length,
                itemBuilder: (context, index) {
                  final isAnswered = _answers.containsKey(widget.test.questions[index].id);
                  final isCurrent = index == _currentQuestionIndex;
                  
                  return InkWell(
                    onTap: () {
                      _goToQuestion(index);
                      Navigator.of(context).pop();
                    },
                    child: Container(
                      decoration: BoxDecoration(
                        color: isCurrent
                            ? AppColors.primaryPurple
                            : isAnswered
                                ? AppColors.success
                                : AppColors.lightGray,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Center(
                        child: Text(
                          '${index + 1}',
                          style: TextStyle(
                            color: isCurrent || isAnswered
                                ? AppColors.white
                                : AppColors.darkGray,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

