import 'package:flutter/material.dart';
import '../constants/app_colors.dart';

class BatchesScreen extends StatelessWidget {
  const BatchesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('My Batches'),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: const Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            // TODO: Implement batches list
            Center(
              child: Text(
                'Batches Screen\n(Coming Soon)',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 18,
                  color: AppColors.mediumGray,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

