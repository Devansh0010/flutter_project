# Material Hub X - Developer Guide

This guide provides comprehensive information for developers working on the Material Hub X project, including architecture, code structure, and development best practices.

## 🏗️ Project Architecture

### Overview
Material Hub X follows a clean architecture pattern with clear separation of concerns:

```
lib/
├── main.dart                 # App entry point
├── firebase_options.dart     # Firebase configuration
├── constants/               # App-wide constants
│   ├── app_colors.dart      # Color definitions
│   └── app_theme.dart       # Theme configuration
├── models/                  # Data models
│   ├── user_model.dart      # User data structure
│   ├── test_model.dart      # Test and question models
│   └── material_model.dart  # Study material models
├── services/                # Business logic and external APIs
│   ├── auth_service.dart    # Authentication logic
│   ├── firestore_service.dart # Database operations
│   ├── xp_service.dart      # XP system logic
│   ├── download_service.dart # File download handling
│   ├── security_service.dart # Security features
│   └── theme_service.dart   # Theme management
├── screens/                 # UI screens
│   ├── home_screen.dart     # Main dashboard
│   ├── auth/               # Authentication screens
│   ├── test_screen.dart    # Test taking interface
│   ├── library_screen.dart # Material library
│   ├── doubt_screen.dart   # Doubt resolution
│   └── leaderboard_screen.dart # Rankings
└── widgets/                # Reusable UI components
    ├── preparation_meter_card.dart
    ├── quick_access_grid.dart
    ├── explore_section.dart
    └── theme_toggle_button.dart
```

### Design Patterns

#### 1. Provider Pattern (State Management)
```dart
// Used for global state management
ChangeNotifierProvider<AuthService>(
  create: (_) => AuthService(),
  child: MaterialApp(...),
)
```

#### 2. Service Layer Pattern
```dart
// Services handle business logic
class FirestoreService {
  static Future<List<MaterialModel>> getMaterials() async {
    // Database operations
  }
}
```

#### 3. Repository Pattern
```dart
// Abstract data access
abstract class UserRepository {
  Future<UserModel> getUser(String uid);
  Future<void> updateUser(UserModel user);
}
```

## 🔧 Development Setup

### Prerequisites
- Flutter SDK 3.24.5+
- Dart SDK 3.0+
- Android Studio / VS Code
- Firebase CLI
- Git

### Environment Setup

1. **Clone Repository**
```bash
git clone <repository-url>
cd material_hub_x
```

2. **Install Dependencies**
```bash
flutter pub get
```

3. **Configure Firebase**
- Follow FIREBASE_SETUP.md
- Place google-services.json in android/app/

4. **Run Development Server**
```bash
flutter run
```

### Development Workflow

1. **Create Feature Branch**
```bash
git checkout -b feature/new-feature
```

2. **Make Changes**
- Follow coding standards
- Add tests for new features
- Update documentation

3. **Test Changes**
```bash
flutter test
flutter analyze
```

4. **Submit Pull Request**
- Ensure all tests pass
- Include description of changes
- Request code review

## 📊 Data Models

### User Model
```dart
class UserModel {
  final String uid;
  final String email;
  final String name;
  final String selectedInstitute;
  final String selectedClass;
  final int xp;
  final int rank;
  final DateTime createdAt;
  final DateTime lastActiveAt;
  final Map<String, dynamic> preferences;

  // Constructor, fromJson, toJson methods
}
```

### Test Model
```dart
class TestModel {
  final String id;
  final String title;
  final String description;
  final String institute;
  final String subject;
  final String difficulty;
  final int duration; // in minutes
  final int totalQuestions;
  final List<QuestionModel> questions;
  final DateTime createdAt;
  final bool isActive;
}

class QuestionModel {
  final String id;
  final String question;
  final List<String> options;
  final int correctAnswer;
  final String explanation;
  final int marks;
}
```

### Material Model
```dart
class MaterialModel {
  final String id;
  final String title;
  final String description;
  final String institute;
  final String subject;
  final String type; // pdf, video, notes, assignment
  final String downloadUrl;
  final String? thumbnailUrl;
  final int fileSize;
  final DateTime uploadedAt;
  final bool isPremium;
  final List<String> tags;
}
```

## 🔥 Firebase Integration

### Authentication Service
```dart
class AuthService extends ChangeNotifier {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  User? _user;
  
  User? get user => _user;
  bool get isLoggedIn => _user != null;
  
  Future<UserCredential?> signInWithEmailAndPassword(
    String email, 
    String password
  ) async {
    try {
      final credential = await _auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );
      _user = credential.user;
      notifyListeners();
      return credential;
    } catch (e) {
      throw Exception('Login failed: $e');
    }
  }
}
```

### Firestore Service
```dart
class FirestoreService {
  static final FirebaseFirestore _db = FirebaseFirestore.instance;
  
  // Get materials with filtering
  static Future<List<MaterialModel>> getMaterials({
    String? institute,
    String? subject,
    String? type,
  }) async {
    Query query = _db.collection('materials');
    
    if (institute != null) {
      query = query.where('institute', isEqualTo: institute);
    }
    if (subject != null) {
      query = query.where('subject', isEqualTo: subject);
    }
    if (type != null) {
      query = query.where('type', isEqualTo: type);
    }
    
    final snapshot = await query.get();
    return snapshot.docs
        .map((doc) => MaterialModel.fromJson(doc.data() as Map<String, dynamic>))
        .toList();
  }
}
```

## 🎨 UI Components

### Custom Widgets

#### Preparation Meter Card
```dart
class PreparationMeterCard extends StatelessWidget {
  final int currentXP;
  final int targetXP;
  final double progressPercentage;
  
  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Preparation Meter'),
            Text('Assigned based on comparison with toppers'),
            LinearProgressIndicator(value: progressPercentage),
          ],
        ),
      ),
    );
  }
}
```

#### Quick Access Grid
```dart
class QuickAccessGrid extends StatelessWidget {
  final List<QuickAccessItem> items = [
    QuickAccessItem('My Batches', Icons.class_, () {}),
    QuickAccessItem('Battleground', Icons.sports_esports, () {}),
    // ... more items
  ];
  
  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      shrinkWrap: true,
      physics: NeverScrollableScrollPhysics(),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        childAspectRatio: 1.0,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
      ),
      itemCount: items.length,
      itemBuilder: (context, index) => _buildGridItem(items[index]),
    );
  }
}
```

### Theme Management
```dart
class AppTheme {
  static ThemeData lightTheme = ThemeData(
    primarySwatch: MaterialColor(0xFF6B46C1, {
      50: Color(0xFFF3F0FF),
      100: Color(0xFFE9E2FF),
      // ... color shades
    }),
    colorScheme: ColorScheme.fromSeed(
      seedColor: AppColors.primaryPurple,
      brightness: Brightness.light,
    ),
    // ... other theme properties
  );
  
  static ThemeData darkTheme = ThemeData(
    colorScheme: ColorScheme.fromSeed(
      seedColor: AppColors.primaryPurple,
      brightness: Brightness.dark,
    ),
    // ... dark theme properties
  );
}
```

## 🔒 Security Implementation

### Screenshot Protection
```dart
class SecurityService {
  static Future<void> enableProtection() async {
    try {
      if (!kIsWeb && Platform.isAndroid) {
        await FlutterWindowManager.addFlags(
          FlutterWindowManager.FLAG_SECURE
        );
      }
    } catch (e) {
      print('Error enabling security protection: $e');
    }
  }
}
```

### Secure Downloads
```dart
class DownloadService {
  static Future<String?> downloadMaterial(
    MaterialModel material,
    AuthService authService,
  ) async {
    if (!authService.isLoggedIn) {
      throw Exception('Authentication required');
    }
    
    // Download to app-specific directory
    final directory = await getApplicationDocumentsDirectory();
    final filePath = '${directory.path}/downloads/${material.id}.pdf';
    
    // Download with authentication headers
    final response = await http.get(
      Uri.parse(material.downloadUrl),
      headers: {
        'Authorization': 'Bearer ${await authService.getIdToken()}',
      },
    );
    
    if (response.statusCode == 200) {
      final file = File(filePath);
      await file.writeAsBytes(response.bodyBytes);
      
      // Log download
      await FirestoreService.logDownload(
        authService.user!.uid,
        material.id,
        filePath,
      );
      
      return filePath;
    }
    
    return null;
  }
}
```

## 🧪 Testing

### Unit Tests
```dart
// test/services/auth_service_test.dart
void main() {
  group('AuthService', () {
    late AuthService authService;
    
    setUp(() {
      authService = AuthService();
    });
    
    test('should sign in with valid credentials', () async {
      // Mock Firebase Auth
      // Test sign in functionality
    });
    
    test('should throw exception for invalid credentials', () async {
      // Test error handling
    });
  });
}
```

### Widget Tests
```dart
// test/widgets/preparation_meter_test.dart
void main() {
  testWidgets('PreparationMeterCard displays correctly', (tester) async {
    await tester.pumpWidget(
      MaterialApp(
        home: PreparationMeterCard(
          currentXP: 150,
          targetXP: 200,
          progressPercentage: 0.75,
        ),
      ),
    );
    
    expect(find.text('Preparation Meter'), findsOneWidget);
    expect(find.byType(LinearProgressIndicator), findsOneWidget);
  });
}
```

### Integration Tests
```dart
// integration_test/app_test.dart
void main() {
  group('Material Hub X Integration Tests', () {
    testWidgets('complete user flow', (tester) async {
      app.main();
      await tester.pumpAndSettle();
      
      // Test login flow
      await tester.tap(find.text('Login'));
      await tester.pumpAndSettle();
      
      // Test navigation
      await tester.tap(find.text('Library'));
      await tester.pumpAndSettle();
      
      // Verify UI elements
      expect(find.text('Library'), findsOneWidget);
    });
  });
}
```

## 📱 Platform-Specific Code

### Android Configuration
```xml
<!-- android/app/src/main/AndroidManifest.xml -->
<manifest xmlns:android="http://schemas.android.com/apk/res/android">
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" />
    
    <application
        android:label="Material Hub X"
        android:name="${applicationName}"
        android:icon="@mipmap/ic_launcher">
        
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:launchMode="singleTop"
            android:theme="@style/LaunchTheme">
            
            <intent-filter android:autoVerify="true">
                <action android:name="android.intent.action.MAIN"/>
                <category android:name="android.intent.category.LAUNCHER"/>
            </intent-filter>
        </activity>
    </application>
</manifest>
```

### Build Configuration
```gradle
// android/app/build.gradle
android {
    compileSdkVersion 33
    ndkVersion flutter.ndkVersion
    
    defaultConfig {
        applicationId "com.example.material_hub_x"
        minSdkVersion 21
        targetSdkVersion 33
        versionCode flutterVersionCode.toInteger()
        versionName flutterVersionName
    }
    
    buildTypes {
        release {
            signingConfig signingConfigs.release
            minifyEnabled true
            proguardFiles getDefaultProguardFile('proguard-android.txt'), 'proguard-rules.pro'
        }
    }
}
```

## 🚀 Performance Optimization

### Image Optimization
```dart
// Use cached network images
CachedNetworkImage(
  imageUrl: material.thumbnailUrl,
  placeholder: (context, url) => CircularProgressIndicator(),
  errorWidget: (context, url, error) => Icon(Icons.error),
  memCacheWidth: 200,
  memCacheHeight: 200,
)
```

### List Performance
```dart
// Use ListView.builder for large lists
ListView.builder(
  itemCount: materials.length,
  itemBuilder: (context, index) {
    return MaterialCard(material: materials[index]);
  },
)
```

### State Management Optimization
```dart
// Use Selector for specific state updates
Selector<AuthService, bool>(
  selector: (context, authService) => authService.isLoggedIn,
  builder: (context, isLoggedIn, child) {
    return isLoggedIn ? HomeScreen() : LoginScreen();
  },
)
```

## 🔍 Debugging

### Debug Tools
```dart
// Enable debug mode
void main() {
  if (kDebugMode) {
    // Enable Firebase emulator
    FirebaseFirestore.instance.useFirestoreEmulator('localhost', 8080);
  }
  runApp(MyApp());
}
```

### Logging
```dart
// Use proper logging
import 'package:logger/logger.dart';

final logger = Logger();

class AuthService {
  Future<void> signIn(String email, String password) async {
    logger.i('Attempting sign in for: $email');
    try {
      // Sign in logic
      logger.i('Sign in successful');
    } catch (e) {
      logger.e('Sign in failed: $e');
      rethrow;
    }
  }
}
```

## 📦 Build & Deployment

### Build Commands
```bash
# Debug build
flutter build apk --debug

# Release build
flutter build apk --release

# App bundle for Play Store
flutter build appbundle --release

# Build with specific flavor
flutter build apk --flavor production --release
```

### CI/CD Pipeline
```yaml
# .github/workflows/flutter.yml
name: Flutter CI/CD

on:
  push:
    branches: [ main, develop ]
  pull_request:
    branches: [ main ]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v3
    - uses: subosito/flutter-action@v2
      with:
        flutter-version: '3.24.5'
    - run: flutter pub get
    - run: flutter analyze
    - run: flutter test
    
  build:
    needs: test
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v3
    - uses: subosito/flutter-action@v2
    - run: flutter pub get
    - run: flutter build apk --release
    - uses: actions/upload-artifact@v3
      with:
        name: release-apk
        path: build/app/outputs/flutter-apk/app-release.apk
```

## 🔧 Maintenance

### Code Quality
- Use `flutter analyze` regularly
- Follow Dart style guide
- Maintain test coverage >80%
- Use meaningful commit messages

### Performance Monitoring
- Monitor app startup time
- Track memory usage
- Monitor network requests
- Use Firebase Performance

### Error Handling
```dart
// Global error handling
void main() {
  FlutterError.onError = (details) {
    FirebaseCrashlytics.instance.recordFlutterFatalError(details);
  };
  
  PlatformDispatcher.instance.onError = (error, stack) {
    FirebaseCrashlytics.instance.recordError(error, stack, fatal: true);
    return true;
  };
  
  runApp(MyApp());
}
```

## 📚 Resources

### Documentation
- [Flutter Documentation](https://flutter.dev/docs)
- [Firebase Documentation](https://firebase.google.com/docs)
- [Dart Language Tour](https://dart.dev/guides/language/language-tour)

### Tools
- [Flutter Inspector](https://flutter.dev/docs/development/tools/flutter-inspector)
- [Firebase Console](https://console.firebase.google.com/)
- [Android Studio](https://developer.android.com/studio)

### Best Practices
- [Flutter Best Practices](https://flutter.dev/docs/development/best-practices)
- [Effective Dart](https://dart.dev/guides/language/effective-dart)
- [Firebase Best Practices](https://firebase.google.com/docs/guides)

---

**Happy Coding!** 🚀

This developer guide should help you understand the codebase and contribute effectively to the Material Hub X project.

