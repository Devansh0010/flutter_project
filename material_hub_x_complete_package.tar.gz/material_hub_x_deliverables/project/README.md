# Material Hub X

A comprehensive educational mobile application designed for IIT JEE, NEET, and UPSC aspirants. Built with Flutter and Firebase, Material Hub X provides a modern, secure, and feature-rich platform for competitive exam preparation.

## 🎯 Features

### 📚 Core Functionality
- **Institute Selection**: Choose from multiple coaching institutes (ARJUNA JEE 2026, PHOENIX NEET 2026, etc.)
- **Material Library**: Access PDFs, videos, notes, and assignments with advanced filtering
- **Test Series**: Take timed tests with automatic scoring and detailed analytics
- **XP System**: Earn experience points for activities and track progress
- **Leaderboard**: Compete with peers and track rankings
- **Doubt Resolution**: Submit doubts and get help from teachers and peers

### 🔒 Security Features
- **Login Required Downloads**: Materials can only be downloaded by authenticated users
- **Screenshot Protection**: Prevents screenshots and screen recording during tests
- **Secure PDF Access**: Downloaded materials are stored securely within the app
- **Firebase Authentication**: Secure user authentication and data protection

### 🎨 User Interface
- **Modern Design**: Clean, intuitive interface with purple, white, and navy blue theme
- **Light/Dark Mode**: Toggle between light and dark themes
- **Responsive Layout**: Optimized for various screen sizes
- **Smooth Animations**: Engaging user experience with smooth transitions

### 📊 Progress Tracking
- **XP System**: 1 XP every 2 minutes of app usage
- **Test Analytics**: Detailed performance analysis and improvement suggestions
- **Progress Meter**: Visual representation of preparation level
- **Achievement System**: Unlock achievements based on performance

## 🛠️ Technology Stack

- **Frontend**: Flutter (Dart)
- **Backend**: Firebase (Firestore, Authentication, Storage)
- **State Management**: Provider
- **Local Storage**: SharedPreferences
- **Security**: Flutter Window Manager for screenshot protection

## 📱 Screens

1. **Home Screen**: Dashboard with XP display, quick access grid, and explore section
2. **Login/Signup**: Firebase authentication with email/password
3. **Institute Selection**: Choose preferred coaching institute
4. **Library**: Browse and download study materials
5. **Test Screen**: Take timed tests with question navigation
6. **Leaderboard**: View rankings and compete with peers
7. **Doubt Screen**: Submit and resolve academic doubts
8. **Profile**: User settings and preferences

## 🚀 Getting Started

### Prerequisites
- Flutter SDK (3.24.5 or later)
- Android Studio / VS Code
- Firebase project setup
- Android SDK for building APKs

### Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd material_hub_x
   ```

2. **Install dependencies**
   ```bash
   flutter pub get
   ```

3. **Firebase Setup**
   - Create a new Firebase project
   - Enable Authentication (Email/Password)
   - Create Firestore database
   - Enable Firebase Storage
   - Download `google-services.json` and place in `android/app/`
   - Update `lib/firebase_options.dart` with your project configuration

4. **Run the app**
   ```bash
   flutter run
   ```

### Building APK

1. **Debug APK**
   ```bash
   flutter build apk --debug
   ```

2. **Release APK**
   ```bash
   flutter build apk --release
   ```

## 🔧 Configuration

### Firebase Configuration
Update the following files with your Firebase project details:
- `lib/firebase_options.dart`
- `android/app/google-services.json`

### Security Rules
Deploy the provided Firestore and Storage security rules:
- `firestore.rules`
- `storage.rules`

## 📊 Database Structure

### Collections

#### Users
```json
{
  "uid": "string",
  "email": "string",
  "name": "string",
  "selectedInstitute": "string",
  "selectedClass": "string",
  "xp": "number",
  "rank": "number",
  "createdAt": "timestamp",
  "lastActiveAt": "timestamp",
  "preferences": "object"
}
```

#### Tests
```json
{
  "id": "string",
  "title": "string",
  "description": "string",
  "institute": "string",
  "subject": "string",
  "difficulty": "string",
  "duration": "number",
  "totalQuestions": "number",
  "questions": "array",
  "createdAt": "timestamp",
  "isActive": "boolean"
}
```

#### Materials
```json
{
  "id": "string",
  "title": "string",
  "description": "string",
  "institute": "string",
  "subject": "string",
  "type": "string",
  "downloadUrl": "string",
  "fileSize": "number",
  "uploadedAt": "timestamp",
  "isPremium": "boolean",
  "tags": "array"
}
```

## 🎮 Usage

### For Students
1. **Sign up** with email and password
2. **Select your institute** from the available options
3. **Browse materials** in the library and download for offline access
4. **Take tests** to assess your preparation level
5. **Submit doubts** and get help from the community
6. **Track progress** through XP system and leaderboard

### For Administrators
1. Upload study materials to Firebase Storage
2. Create tests with questions and answers
3. Manage user access and permissions
4. Monitor app usage and analytics

## 🔐 Security Features

### Data Protection
- All user data is encrypted and stored securely in Firebase
- Materials can only be accessed by authenticated users
- Downloaded files are stored in app-specific directories

### Screenshot Protection
- Prevents screenshots during test sessions
- Blocks screen recording on Android devices
- Security warnings for violation attempts

### Authentication
- Firebase Authentication with email/password
- Secure session management
- Automatic logout on security violations

## 🎨 Customization

### Themes
The app supports both light and dark themes. Colors can be customized in:
- `lib/constants/app_colors.dart`
- `lib/constants/app_theme.dart`

### Institute Configuration
Add new institutes by updating:
- `lib/screens/institute_selection_screen.dart`
- Firebase database with new institute materials

## 📈 Analytics & Monitoring

### XP System
- 1 XP per 2 minutes of app usage
- Bonus XP for completing tests
- Daily login bonuses
- Achievement-based rewards

### Performance Tracking
- Test completion rates
- Average scores and improvement trends
- Time spent on different subjects
- Download and usage statistics

## 🐛 Troubleshooting

### Common Issues

1. **Firebase Connection Issues**
   - Verify `google-services.json` is correctly placed
   - Check internet connectivity
   - Ensure Firebase project is properly configured

2. **Build Failures**
   - Run `flutter clean` and `flutter pub get`
   - Check Android SDK installation
   - Verify all dependencies are compatible

3. **Authentication Problems**
   - Enable Email/Password authentication in Firebase Console
   - Check security rules are properly deployed
   - Verify API keys are correct

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## 📞 Support

For support and questions:
- Create an issue in the repository
- Contact the development team
- Check the documentation for common solutions

## 🔄 Version History

### v1.0.0 (Current)
- Initial release with core functionality
- Firebase integration
- Security features implementation
- XP system and leaderboard
- Material download system
- Test taking interface
- Doubt resolution system

---

**Material Hub X** - Empowering students for competitive exam success! 🎓

